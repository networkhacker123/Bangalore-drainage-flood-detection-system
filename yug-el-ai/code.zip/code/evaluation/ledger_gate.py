"""Reproducible, privacy-bounded Phase 05 full-corpus acceptance gate."""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys

CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from buywait.adapters.dataset import load_dataset
from buywait.domain.enums import CashState, Direction, LifecycleDisposition
from buywait.evidence.service import EvidenceService
from buywait.ledger import CanonicalLedgerBuilder
from buywait.providers.local_ocr import local_ocr


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate canonical-ledger invariants across participant inputs")
    parser.add_argument("--dataset-dir")
    parser.add_argument("--ocr", choices=("auto", "rapidocr", "windows", "tesseract", "none"), default="auto")
    parser.add_argument("--report")
    args = parser.parse_args()

    context = load_dataset(args.dataset_dir)
    evidence_service = EvidenceService(context, ocr=local_ocr(args.ocr), model=None, cache=None)
    builder = CanonicalLedgerBuilder()
    requests = context.evaluation_requests + context.sample_requests
    disposition_counts: Counter[str] = Counter()
    rule_counts: Counter[str] = Counter()
    warning_counts: Counter[str] = Counter()
    failures: list[dict] = []
    unresolved: list[dict] = []
    ledger_fingerprints: set[str] = set()
    disposed_source_ids: list[str] = []
    event_rows = 0
    flows = historical_flows = forecast_flows = 0
    evidence_facts = evidence_conflicts = 0
    evidence_ready_requests = mandatory_resolved = mandatory_total = 0

    for request in requests:
        bundle = context.bundle(request.request_id)
        evidence = evidence_service.evaluate(request.request_id)
        evidence_facts += len(evidence.facts)
        evidence_conflicts += len(evidence.conflicts)
        evidence_ready_requests += int(evidence.ready)
        mandatory_resolved += len(evidence.resolved_event_ids)
        mandatory_total += len(evidence.mandatory_event_ids)
        ledger = builder.build(bundle, evidence)
        expected = {event.event_id for event in bundle.events}
        actual = [item.event_id for item in ledger.event_dispositions]
        checks = {
            "one_disposition_per_event": len(actual) == len(set(actual)) and set(actual) == expected,
            "balance_anchor_unchanged": ledger.current_available_balance == bundle.profile.current_available_balance,
            "all_flows_home_currency": all(flow.amount.currency == bundle.profile.home_currency for flow in ledger.flows),
            "history_not_forecast": all(flow.cash_state is CashState.HISTORICAL for flow in ledger.historical_flows),
            "ignored_pending_credit_has_no_flow": all(
                item.flow_id is None for item in ledger.event_dispositions
                if item.disposition is LifecycleDisposition.PENDING_CREDIT_IGNORED
            ),
            "every_exclusion_explained": all(item.rule_code and item.explanation for item in ledger.event_dispositions),
        }
        if not all(checks.values()):
            failures.append({"request_id": request.request_id,
                             "failed_checks": sorted(name for name, passed in checks.items() if not passed)})
        unresolved_ids = [item.event_id for item in ledger.event_dispositions
                          if item.disposition is LifecycleDisposition.UNRESOLVED]
        if unresolved_ids:
            unresolved.append({"request_id": request.request_id, "event_ids": unresolved_ids})
        event_rows += len(actual)
        disposed_source_ids.extend(actual)
        flows += len(ledger.flows)
        historical_flows += len(ledger.historical_flows)
        forecast_flows += len(ledger.forecast_flows)
        disposition_counts.update(item.disposition.value for item in ledger.event_dispositions)
        rule_counts.update(item.rule_code for item in ledger.event_dispositions)
        warning_counts.update(item.code for item in ledger.warnings)
        ledger_fingerprints.add(ledger.fingerprint)

    global_checks = {
        "all_source_events_disposed_once": (
            len(disposed_source_ids) == len(set(disposed_source_ids)) == len(context.events)
            and set(disposed_source_ids) == set(context.events_by_id)
        ),
        "one_ledger_per_request": len(ledger_fingerprints) == len(requests),
        "no_per_request_invariant_failure": not failures,
    }
    report = {
        "schema_version": "buywait.ledger-gate.v1",
        "passed": all(global_checks.values()),
        "requests": len(requests),
        "unique_users": len({request.user_id for request in requests}),
        "event_dispositions": event_rows,
        "source_events": len(context.events),
        "flows": flows,
        "historical_flows": historical_flows,
        "forecast_flows": forecast_flows,
        "evidence_facts": evidence_facts,
        "evidence_conflicts": evidence_conflicts,
        "evidence_ready_requests": evidence_ready_requests,
        "mandatory_amounts_resolved": mandatory_resolved,
        "mandatory_amounts_unresolved": mandatory_total - mandatory_resolved,
        "distinct_fingerprints": len(ledger_fingerprints),
        "disposition_counts": dict(sorted(disposition_counts.items())),
        "rule_counts": dict(sorted(rule_counts.items())),
        "warning_counts": dict(sorted(warning_counts.items())),
        "global_checks": global_checks,
        "unresolved": unresolved,
        "failures": failures,
        "network_model_calls": 0,
    }
    rendered = json.dumps(report, sort_keys=True, indent=2) + "\n"
    if args.report:
        target = Path(args.report)
        if not target.is_absolute():
            target = CODE_DIR.parent / target
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
