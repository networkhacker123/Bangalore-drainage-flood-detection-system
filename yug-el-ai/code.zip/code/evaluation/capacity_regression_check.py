"""Check the scoped capacity fix against the frozen release, without plan search."""
from decimal import Decimal
import json
from pathlib import Path
import sys

CODE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE_DIR))

from buywait.adapters.dataset import load_dataset
from buywait.evidence.service import EvidenceService
from buywait.forecasting import ForecastEngine
from buywait.ledger import CanonicalLedgerBuilder
from buywait.providers.local_ocr import local_ocr


class CapacityOnlyEngine(ForecastEngine):
    def _earliest(self, *args):
        # Dates and plan selection are deliberately outside this regression.
        return None


def main():
    context = load_dataset()
    evidence = EvidenceService(context, ocr=local_ocr("auto"), model=None, cache=None)
    builder = CanonicalLedgerBuilder()
    engine = CapacityOnlyEngine()
    changes = []
    unresolved = []
    requests = (*context.sample_requests, *context.evaluation_requests)
    for request in requests:
        extracted = evidence.evaluate(request.request_id)
        ledger = builder.build(context.bundle(request.request_id), extracted)
        assessment = engine.assess(ledger, request.requested_amount, extracted.facts)
        base = assessment.baseline
        old = Decimal(0)
        if base.safety_result.safe:
            old = max(Decimal(0), min(request.requested_amount.amount,
                min(day.lowest_intraday_balance.amount for day in base.days)
                - ledger.minimum_balance_to_keep.amount))
        if old != assessment.amount_safe_to_pay.amount:
            changes.append({"request_id": request.request_id, "before": str(old),
                            "after": str(assessment.amount_safe_to_pay.amount)})
        if assessment.timeline.unresolved_event_ids:
            unresolved.append(request.request_id)
    report = {"requests_checked": len(requests), "capacity_changes": changes,
              "unresolved_requests": unresolved, "network_model_calls": 0,
              "scope": "capacity-only regression; not a fresh complete decision gate"}
    target = CODE_DIR.parent / "docs/contracts/capacity_regression_check.json"
    target.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
