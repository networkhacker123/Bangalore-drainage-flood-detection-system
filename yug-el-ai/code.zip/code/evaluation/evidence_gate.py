"""Repeatable Phase 04 gate. Public sample-image fixtures only; never imported by runtime."""
from __future__ import annotations
import argparse
from datetime import date
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from buywait.adapters.dataset import load_dataset
from buywait.evidence.cache import EvidenceCache
from buywait.evidence.service import EvidenceService
from buywait.providers.local_ocr import local_ocr


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-dir")
    parser.add_argument("--report", type=Path)
    parser.add_argument("--no-cache", action="store_true")
    args = parser.parse_args()
    context = load_dataset(args.dataset_dir)
    before = hashes(context.dataset_dir)
    code_dir = Path(__file__).resolve().parents[1]
    root = code_dir.parent if code_dir.name == "code" else code_dir
    if args.report and args.report.resolve().is_relative_to(context.dataset_dir):
        parser.error("Report must be outside the read-only dataset")
    service = EvidenceService(context, ocr=local_ocr(), cache=None if args.no_cache else EvidenceCache(root / ".cache/evidence"))
    report = service.preflight()
    # Independently transcribed from the five public sample-linked PNGs. These
    # are evaluation fixtures, not sample affordability labels or production maps.
    samples = {"request_03": {("4365000", None)}, "request_16": {("100000", None)},
               "request_17": {("41272", None)}, "request_19": {("2854", None)},
               "request_20": {("704.05", None), ("822.05", date(2026, 2, 7))}}
    checks = []
    for request_id, expected in samples.items():
        result = service.evaluate(request_id)
        actual = {(fact.value, fact.effective_date) for fact in result.facts if fact.provenance.source_kind.value == "image" and fact.fact_type.value == "amount"}
        checks.append({"request_id": request_id, "passed": actual == {(Decimal(value), when) for value, when in expected}})
    report.update({"public_image_checks": checks, "public_image_checks_passed": sum(c["passed"] for c in checks),
                   "participant_files": len(before), "participant_files_unchanged": before == hashes(context.dataset_dir),
                   "ocr_provider": service.ocr.provider_id if service.ocr else None, "ocr_version": service.ocr.version if service.ocr else None,
                   "final_prediction_run": False})
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if not report["unresolved"] and all(c["passed"] for c in checks) and report["participant_files_unchanged"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
