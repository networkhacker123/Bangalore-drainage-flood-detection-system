"""Bounded developer probe for unresolved image candidates. Not used for predictions."""
from pathlib import Path
import argparse
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from buywait.adapters.dataset import load_dataset
from buywait.providers.local_ocr import local_ocr
from buywait.evidence.images import interpret_image, spatial_rows
from buywait.evidence.routing import route
from dataclasses import replace
import hashlib

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("request_id")
    args = parser.parse_args()
    context = load_dataset()
    provider = local_ocr()
    for source in route(context.bundle(args.request_id))[0]:
        if source.kind.value != "image":
            continue
        data = context.read_image(args.request_id, source.source_id)
        source = replace(source, content_hash=hashlib.sha256(data).hexdigest())
        for doc in provider.variants(data):
            result = interpret_image(source, doc)
            print({"image_id": source.source_id, "variant": doc.model, "fact_count": len(result.facts),
                   "issues": [i.reason_code for i in result.issues]}, flush=True)
