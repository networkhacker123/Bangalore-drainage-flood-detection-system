"""Developer-only bounded financial-label preview; no full OCR documents or PII."""
from pathlib import Path
import re
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from buywait.adapters.dataset import load_dataset
from buywait.providers.local_ocr import local_ocr
from buywait.evidence.images import spatial_rows

if __name__ == "__main__":
    context = load_dataset()
    provider = local_ocr()
    if provider is None:
        raise SystemExit("No local OCR provider installed")
    for image in context.images:
        request = next(item for item in context.requests_by_id.values() if item.user_id == image.user_id)
        doc = provider.recognize(context.read_image(request.request_id, image.image_id))
        print(image.image_id, flush=True)
        for variant in (doc,):
            print(variant.model, flush=True)
            for text, _ in spatial_rows(variant):
                if re.search(r"total|amount|net pay|balance|item bill|paid|payable|fare|wallet|after|before", text, re.I):
                    print("financial-label-row: [REDACTED]", flush=True)
