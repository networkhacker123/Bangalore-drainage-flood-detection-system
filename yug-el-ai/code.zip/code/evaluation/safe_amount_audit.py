"""Bounded public-only capacity diagnostics; candidate policies never read targets."""
from decimal import Decimal
import argparse
import json
from pathlib import Path
import sys

CODE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE_DIR))

from buywait.adapters.dataset import load_dataset
from buywait.domain.enums import AmountStrategy, Direction
from buywait.domain.models import Payment
from buywait.domain.money import Money
from buywait.evidence.service import EvidenceService
from buywait.forecasting.policy import RELEASE_CANDIDATE_POLICY
from buywait.forecasting.recurrence import RecurrenceDetector
from buywait.forecasting.timeline import ForecastTimelineBuilder
from buywait.forecasting.simulation import ForecastSimulator
from buywait.ledger import CanonicalLedgerBuilder
from buywait.providers.local_ocr import local_ocr


class ProbeDetector(RecurrenceDetector):
    """Evaluation-only hypotheses over general expense categories."""
    def __init__(self, mode):
        super().__init__(recent_window=8, variable_essential_estimator="nearest_rank_p50")
        self.mode = mode

    def _amount(self, observations, protected, category):
        if self.mode == "all_essential_median":
            protected = protected or category.lower() in {"groceries", "healthcare", "transport", "utilities"}
        if self.mode in {"recent_three_midpoint", "recent_three_mean"} and observations[-1].direction is Direction.DEBIT:
            values = [item.amount.amount for item in observations[-3:]]
            if len(set(values)) > 1:
                method = "midpoint_median" if self.mode.endswith("midpoint") else "mean"
                return AmountStrategy.CONSERVATIVE_ROBUST, self._estimate(values, method)
        return super()._amount(observations, protected, category)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", default="docs/contracts/safe_amount_audit.json")
    args = parser.parse_args()
    context = load_dataset()
    evidence = EvidenceService(context, ocr=local_ocr("auto"), model=None, cache=None)
    builder = CanonicalLedgerBuilder()
    modes = ("baseline", "exclude_initial_opening", "horizon_89", "all_essential_median",
             "recent_three_midpoint", "recent_three_mean")
    rows = {mode: [] for mode in modes}
    maximality = []
    for request in context.sample_requests:
        facts = evidence.evaluate(request.request_id)
        ledger = builder.build(context.bundle(request.request_id), facts)
        expected = context.sample_expectations[request.request_id].amount_safe_to_pay.amount
        for mode in modes:
            timeline = ForecastTimelineBuilder(ProbeDetector(mode), horizon_days=89 if mode == "horizon_89" else 90).build(ledger, facts.facts)
            simulator = ForecastSimulator(RELEASE_CANDIDATE_POLICY)
            result = simulator.simulate(timeline, ledger.current_available_balance, ledger.minimum_balance_to_keep)
            balances = [day.lowest_intraday_balance.amount for day in result.days]
            if mode == "exclude_initial_opening":
                # In credit-first mode only post-payment day-zero balances shift.
                balances[0] = result.days[0].closing_balance.amount
            headroom = min(balances) - ledger.minimum_balance_to_keep.amount
            amount = max(Decimal(0), min(request.requested_amount.amount, headroom)) if result.safety_result.safe else Decimal(0)
            delta = abs(amount - expected)
            rows[mode].append({"request_id": request.request_id, "expected": str(expected),
                               "actual": str(amount), "absolute_error": str(delta),
                               "relative_error": str(delta / max(Decimal(1), expected)),
                               "exact": delta == 0, "within_one_percent": delta <= max(Decimal("0.01"), expected / 100)})
            if mode == "baseline" and result.safety_result.safe:
                pay = lambda value: simulator.simulate(timeline, ledger.current_available_balance,
                    ledger.minimum_balance_to_keep,
                    payments=(Payment(request.request_date, Money(value, ledger.home_currency), 1),)).safety_result.safe
                maximality.append({"request_id": request.request_id, "at_capacity_safe": pay(amount),
                    "above_capacity_unsafe_or_request_capped": amount == request.requested_amount.amount or not pay(amount + Decimal("0.01"))})
    report = {"scope": "public_samples_only", "hypotheses": {}, "capacity_checks": maximality}
    for mode, cases in rows.items():
        report["hypotheses"][mode] = {"exact": sum(row["exact"] for row in cases),
            "within_one_percent": sum(row["within_one_percent"] for row in cases),
            "mean_normalized_error": str(sum((Decimal(row["relative_error"]) for row in cases), Decimal(0)) / len(cases)),
            "mean_absolute_error_mixed_currency": str(sum((Decimal(row["absolute_error"]) for row in cases), Decimal(0)) / len(cases)),
            "cases": cases}
    target = Path(args.report)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({mode: {k: v for k, v in value.items() if k != "cases"} for mode, value in report["hypotheses"].items()}, indent=2))
    print("capacity_boundary_checks_passed=", all(row["at_capacity_safe"] and row["above_capacity_unsafe_or_request_capped"] for row in maximality))


if __name__ == "__main__":
    main()
