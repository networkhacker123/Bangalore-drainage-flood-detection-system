# Phase 04 development usage — not the final submission report

The recorded full evidence preflight was local: 275 requests, 16 linked PNGs, 15 mandatory amounts resolved, one unresolved, and all five public sample-image assertions passed.

| Category | Provider/model | Calls/tokens/cost |
|---|---|---|
| Remote LLM/VLM | None enabled | 0 calls, 0 input/output tokens, USD 0 API cost |
| Deterministic messages | Internal templates v2 | No tokens or API charges |
| Local OCR | rapidocr-onnxruntime 1.4.4, det1600-v1 | CPU inference; no text-token accounting or API charges |

Windows OCR and optional crop probes were also exercised during development. Local inference consumes machine resources; zero API cost does not mean zero compute cost. Coding-assistant conversation usage is not measured by the application and is not included here. Mock-provider token/cost values in tests are synthetic and must never enter a real usage report.

The final `output.csv` has not been produced. Do not rename this file to `usage_report.md` or represent it as final-run accounting. The later final prediction run must create `evaluation/usage_report.md` from its actual model-attempt records, per-model and overall totals, request count, per-request averages, pricing and any unknown token/cost flags.
