"""Deterministic source-only packaging and local integrity checks; never uploads."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import shutil
import sys
import tempfile
import zipfile

CODE = Path(__file__).resolve().parents[1]
ROOT = CODE.parent
sys.path.insert(0, str(CODE))
from buywait.forecasting.policy import RELEASE_CANDIDATE_POLICY

SKIP = {'__pycache__', '.cache', '.venv', 'venv', 'node_modules', 'build', 'dist',
        'audit', 'coverage', '.git', '.pytest_cache', '.mypy_cache'}
ALLOWED = {'.py', '.md', '.txt', '.json', '.toml', '.ps1'}
SECRET = re.compile(rb'sk-(?:proj-)?[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pack():
    files = []
    for path in sorted(CODE.rglob('*')):
        rel = path.relative_to(CODE)
        if not path.is_file() or set(rel.parts) & SKIP:
            continue
        if rel.parts[0] in {'dataset', 'data'}:
            continue
        if path.suffix not in ALLOWED or path.name.startswith('.env') or path.name == 'log.txt':
            continue
        if path.is_symlink() or SECRET.search(path.read_bytes()):
            raise RuntimeError('Unsafe package file: ' + str(rel))
        files.append(path)
    destination = ROOT / 'code.zip'
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            name = 'code/' + path.relative_to(CODE).as_posix()
            info = zipfile.ZipInfo(name, (2026, 9, 13, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        assert 'code/evaluation/usage_report.md' in names
        assert all(not set(Path(n).parts) & SKIP for n in names)
    runtime = [(p.relative_to(CODE).as_posix(), sha(p.read_bytes())) for p in files
               if p.suffix in {'.py', '.ps1'}]
    return dict(archive_sha256=sha(destination.read_bytes()), archive_bytes=destination.stat().st_size,
                members=len(files), runtime_fingerprint=sha(json.dumps(runtime).encode()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        # Carry public schema documentation with the source-only package.
        source = ROOT / 'docs/contracts/schemas'
        if source.exists():
            shutil.copytree(source, CODE / 'docs/contracts/schemas', dirs_exist_ok=True)
        dataset = ROOT / 'dataset'
        hashes = {p.relative_to(dataset).as_posix(): sha(p.read_bytes())
                  for p in sorted(dataset.rglob('*')) if p.is_file()}
        profile = json.loads((ROOT/'docs/contracts/dataset_profile.json').read_text(encoding='utf-8'))
        checked = []
        def verify_profile(value, key=''):
            if isinstance(value, dict):
                if 'sha256' in value and key in hashes:
                    assert value['sha256'] == hashes[key], 'Profile hash mismatch: '+key
                    checked.append(key)
                for k, v in value.items():
                    verify_profile(v, k)
        verify_profile(profile)
        assert len(checked) >= 9, 'All CSV profile hashes must be verified'
        transcript = (ROOT/'log.txt').read_bytes()
        assert not SECRET.search(transcript), 'Secret pattern in transcript; never print it'
        assert 'log.txt' in (ROOT/'.gitignore').read_text(encoding='utf-8').splitlines()
        info = pack()
        temp = Path(tempfile.mkdtemp(prefix='buywait-release-'))
        with zipfile.ZipFile(ROOT/'code.zip') as archive:
            archive.extractall(temp)
        info.update(started_utc=datetime.now(timezone.utc).isoformat(),
                    python=sys.version, os=platform.platform(), extracted_dir=str(temp),
                    policy_fingerprint=RELEASE_CANDIDATE_POLICY.fingerprint,
                    dataset_hashes=hashes, profiled_csvs_verified=len(checked),
                    log_prefix_length=len(transcript), log_prefix_sha256=sha(transcript),
                    dependencies={name: importlib.metadata.version(name) for name in
                        ('rapidocr-onnxruntime', 'onnxruntime', 'numpy', 'Pillow')})
        (ROOT/'release_preflight.json').write_text(json.dumps(info, indent=2)+'\n', encoding='utf-8')
        print(json.dumps({k:v for k,v in info.items() if k!='dataset_hashes'}, indent=2))
    else:
        pre = json.loads((ROOT/'release_preflight.json').read_text())
        for name, digest in pre['dataset_hashes'].items():
            assert sha((ROOT/'dataset'/name).read_bytes()) == digest, 'Input modified: '+name
        transcript=(ROOT/'log.txt').read_bytes()
        assert sha(transcript[:pre['log_prefix_length']]) == pre['log_prefix_sha256']
        assert not SECRET.search(transcript)
        info = pack()
        assert info['runtime_fingerprint'] == pre['runtime_fingerprint'], 'Runtime changed after freeze'
        info['transcript_sha256']=sha(transcript)
        info['output_sha256']=sha((ROOT/'output.csv').read_bytes())
        (ROOT/'release_package.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(info,indent=2))


if __name__ == '__main__':
    main()
