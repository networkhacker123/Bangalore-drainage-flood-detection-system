"""Reproducible Phase 06 forecast invariants and public-sample scorecard."""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import timedelta
from decimal import Decimal
import json
from pathlib import Path
import sys

CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from buywait.adapters.dataset import load_dataset
from buywait.evidence.service import EvidenceService
from buywait.forecasting import ForecastEngine
from buywait.ledger import CanonicalLedgerBuilder
from buywait.providers.local_ocr import local_ocr


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate recurrence and inclusive 90-day forecasts")
    parser.add_argument("--dataset-dir")
    parser.add_argument("--ocr", choices=("auto", "rapidocr", "windows", "tesseract", "none"), default="auto")
    parser.add_argument("--samples-only", action="store_true")
    parser.add_argument("--debug-request")
    parser.add_argument("--report")
    args = parser.parse_args()

    context = load_dataset(args.dataset_dir)
    evidence_service = EvidenceService(context, ocr=local_ocr(args.ocr), model=None, cache=None)
    ledger_builder = CanonicalLedgerBuilder()
    engine = ForecastEngine()
    requests = context.sample_requests if args.samples_only else context.evaluation_requests + context.sample_requests
    if args.debug_request:
        requests = tuple(item for item in requests if item.request_id == args.debug_request)
        if not requests:
            parser.error("--debug-request is outside the selected scope")
    failures: list[dict] = []
    unresolved: list[dict] = []
    fingerprints: set[str] = set()
    cadence_counts: Counter[str] = Counter()
    strategy_counts: Counter[str] = Counter()
    origin_counts: Counter[str] = Counter()
    total_rules = total_occurrences = 0
    public: list[dict] = []
    debug = None

    for request in requests:
        evidence = evidence_service.evaluate(request.request_id)
        ledger = ledger_builder.build(context.bundle(request.request_id), evidence)
        assessment = engine.assess(ledger, request.requested_amount, evidence.facts)
        timeline = assessment.timeline
        baseline = assessment.baseline
        checks = {
            "inclusive_91_days": len(baseline.days) == 91,
            "correct_boundaries": (
                baseline.days[0].forecast_date == request.request_date
                and baseline.days[-1].forecast_date == request.request_date + timedelta(days=90)
            ),
            "ordered_unique_days": len({item.forecast_date for item in baseline.days}) == 91,
            "ordered_unique_occurrences": (
                len({item.flow.flow_id for item in timeline.occurrences}) == len(timeline.occurrences)
                and tuple(sorted(timeline.occurrences, key=lambda item: (item.flow.effective_date, item.flow.flow_id)))
                == timeline.occurrences
            ),
            "safe_amount_bounds": Decimal(0) <= assessment.amount_safe_to_pay.amount <= request.requested_amount.amount,
            "currency_exact": all(
                value.currency == ledger.home_currency
                for day in baseline.days
                for value in (day.opening_balance, day.closing_balance, day.lowest_intraday_balance)
            ),
            "unresolved_fails_closed": not timeline.unresolved_event_ids or not baseline.safety_result.safe,
        }
        if not all(checks.values()):
            failures.append({
                "request_id": request.request_id,
                "failed_checks": sorted(name for name, passed in checks.items() if not passed),
            })
        if timeline.unresolved_event_ids:
            unresolved.append({"request_id": request.request_id, "event_ids": list(timeline.unresolved_event_ids)})
        fingerprints.add(timeline.fingerprint)
        cadence_counts.update(rule.cadence.value for rule in timeline.recurrence_rules)
        strategy_counts.update(rule.amount_strategy.value for rule in timeline.recurrence_rules)
        origin_counts.update(item.origin.value for item in timeline.occurrences)
        total_rules += len(timeline.recurrence_rules)
        total_occurrences += len(timeline.occurrences)

        if args.debug_request == request.request_id:
            debug = {
                "request_id": request.request_id,
                "request_date": request.request_date.isoformat(),
                "starting_balance": str(ledger.current_available_balance.amount),
                "floor": str(ledger.minimum_balance_to_keep.amount),
                "baseline_minimum": str(baseline.safety_result.minimum_projected_balance.amount),
                "tightest_date": baseline.safety_result.tightest_date.isoformat(),
                "rules": [{
                    "category": rule.category,
                    "direction": rule.direction.value,
                    "amount": str(rule.amount.amount),
                    "cadence": rule.cadence.value,
                    "interval": rule.interval,
                    "anchor": rule.anchor_date.isoformat(),
                    "observed": rule.observed_count,
                } for rule in timeline.recurrence_rules],
                "occurrences": [{
                    "date": item.flow.effective_date.isoformat(),
                    "category": item.flow.category,
                    "direction": item.flow.direction.value,
                    "amount": str(item.flow.amount.amount),
                    "origin": item.origin.value,
                } for item in timeline.occurrences],
            }

        expected = context.sample_expectations.get(request.request_id)
        if expected is not None:
            amount_delta = assessment.amount_safe_to_pay.amount - expected.amount_safe_to_pay.amount
            date_match = assessment.earliest_date_for_full_payment == expected.earliest_date_for_full_payment
            public.append({
                "request_id": request.request_id,
                "expected_safe_amount": str(expected.amount_safe_to_pay.amount),
                "actual_safe_amount": str(assessment.amount_safe_to_pay.amount),
                "safe_amount_exact": amount_delta == 0,
                "safe_amount_absolute_delta": str(abs(amount_delta)),
                "earliest_date_exact": date_match,
                "expected_earliest_date": (
                    expected.earliest_date_for_full_payment.isoformat()
                    if expected.earliest_date_for_full_payment else None
                ),
                "actual_earliest_date": (
                    assessment.earliest_date_for_full_payment.isoformat()
                    if assessment.earliest_date_for_full_payment else None
                ),
            })

    public_amount_exact = sum(item["safe_amount_exact"] for item in public)
    public_date_exact = sum(item["earliest_date_exact"] for item in public)
    report = {
        "schema_version": "buywait.forecast-gate.v1",
        "passed": not failures,
        "scope": "samples" if args.samples_only else "all_requests_and_samples",
        "requests": len(requests),
        "timeline_fingerprints": len(fingerprints),
        "recurrence_rules": total_rules,
        "forecast_occurrences": total_occurrences,
        "cadence_counts": dict(sorted(cadence_counts.items())),
        "amount_strategy_counts": dict(sorted(strategy_counts.items())),
        "origin_counts": dict(sorted(origin_counts.items())),
        "unresolved": unresolved,
        "public_sample_metrics": {
            "cases": len(public),
            "safe_amount_exact": public_amount_exact,
            "earliest_date_exact": public_date_exact,
            "safe_amount_mean_absolute_delta": str(
                sum((Decimal(item["safe_amount_absolute_delta"]) for item in public), Decimal(0))
                / Decimal(len(public) or 1)
            ),
        },
        "public_sample_deltas": public,
        "debug": debug,
        "failures": failures,
        "network_model_calls": 0,
    }
    rendered = json.dumps(report, sort_keys=True, indent=2) + "\n"
    if args.report:
        target = Path(args.report)
        if not target.is_absolute():
            target = CODE_DIR.parent / target
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
