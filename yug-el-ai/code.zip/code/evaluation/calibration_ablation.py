"""Public-sample policy ablations without request-specific production behavior."""

from __future__ import annotations

import argparse
from decimal import Decimal
import json
from pathlib import Path
import sys

CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from buywait.adapters.dataset import load_dataset
from buywait.evidence.service import EvidenceService
from buywait.forecasting.recurrence import RecurrenceDetector
from buywait.forecasting.simulation import ForecastSimulator
from buywait.forecasting.timeline import ForecastTimelineBuilder
from buywait.forecasting.policy import ForecastPolicy
from buywait.ledger import CanonicalLedgerBuilder
from buywait.providers.local_ocr import local_ocr


ESTIMATORS = ("nearest_rank_p75", "nearest_rank_p50", "mean", "latest", "max")
OTHER_DEBIT_ESTIMATORS = ("latest", "nearest_rank_p50", "mean")
WINDOWS = (3, 4, 5, 6, 8, 12, 1000)


def _safe_amount(timeline, ledger, requested, simulator) -> Decimal:
    baseline = simulator.simulate(
        timeline, ledger.current_available_balance, ledger.minimum_balance_to_keep
    )
    if not baseline.safety_result.safe:
        return Decimal(0)
    headroom = min(
        day.lowest_intraday_balance.amount - ledger.minimum_balance_to_keep.amount
        for day in baseline.days
    )
    return max(Decimal(0), min(requested.amount, headroom))


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare immutable global forecast policies")
    parser.add_argument("--dataset-dir")
    parser.add_argument("--ocr", choices=("auto", "rapidocr", "windows", "tesseract", "none"), default="auto")
    parser.add_argument("--report")
    args = parser.parse_args()

    context = load_dataset(args.dataset_dir)
    evidence_service = EvidenceService(context, ocr=local_ocr(args.ocr), model=None, cache=None)
    ledger_builder = CanonicalLedgerBuilder()
    cases = []
    for request in context.sample_requests:
        evidence = evidence_service.evaluate(request.request_id)
        ledger = ledger_builder.build(context.bundle(request.request_id), evidence)
        cases.append((request, evidence, ledger, context.sample_expectations[request.request_id]))

    policies = []
    for estimator in ESTIMATORS:
        for other_estimator in OTHER_DEBIT_ESTIMATORS:
            for window in WINDOWS:
                policies.append(ForecastPolicy(
                    confirmed_credits_before_same_day_payments=True,
                    include_inferred_recurrence_on_request_date=True,
                    variable_essential_estimator=estimator,
                    variable_essential_window=window,
                    other_recurring_debit_estimator=other_estimator,
                ))

    results = []
    for policy in policies:
        detector = RecurrenceDetector(
            minimum_observations=policy.minimum_recurrence_observations,
            recent_window=policy.variable_essential_window,
            variable_essential_estimator=policy.variable_essential_estimator,
            other_recurring_debit_estimator=policy.other_recurring_debit_estimator,
        )
        builder = ForecastTimelineBuilder(
            detector,
            horizon_days=policy.horizon_days,
            include_inferred_recurrence_on_request_date=policy.include_inferred_recurrence_on_request_date,
        )
        simulator = ForecastSimulator(policy)
        deltas = []
        exact = 0
        within_one_percent = 0
        per_case = []
        for request, evidence, ledger, expected in cases:
            timeline = builder.build(ledger, evidence.facts)
            actual = _safe_amount(timeline, ledger, request.requested_amount, simulator)
            delta = abs(actual - expected.amount_safe_to_pay.amount)
            tolerance = max(Decimal("0.01"), expected.amount_safe_to_pay.amount * Decimal("0.01"))
            deltas.append(delta)
            exact += int(delta == 0)
            within_one_percent += int(delta <= tolerance)
            per_case.append({
                "request_id": request.request_id,
                "expected": str(expected.amount_safe_to_pay.amount),
                "actual": str(actual),
                "absolute_delta": str(delta),
            })
        results.append({
            "policy_fingerprint": policy.fingerprint,
            "estimator": policy.variable_essential_estimator,
            "window": policy.variable_essential_window,
            "other_debit_estimator": policy.other_recurring_debit_estimator,
            "safe_amount_exact": exact,
            "safe_amount_within_one_percent": within_one_percent,
            "mean_absolute_delta": str(sum(deltas, Decimal(0)) / Decimal(len(deltas))),
            "normalized_absolute_error": str(sum(
                delta / max(Decimal(1), expected.amount_safe_to_pay.amount)
                for delta, (_, _, _, expected) in zip(deltas, cases)
            ) / Decimal(len(deltas))),
            "per_case": per_case,
        })
    results.sort(key=lambda item: (
        -item["safe_amount_exact"],
        -item["safe_amount_within_one_percent"],
        Decimal(item["normalized_absolute_error"]),
        Decimal(item["mean_absolute_delta"]),
        item["estimator"],
        item["other_debit_estimator"],
        item["window"],
    ))
    report = {
        "schema_version": "buywait.calibration-ablation.v1",
        "public_samples": len(cases),
        "policy_count": len(results),
        "ranking_rule": "exact, within_1pct, normalized_error, mean_absolute_delta",
        "results": results,
    }
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.report:
        target = Path(args.report)
        if not target.is_absolute():
            target = CODE_DIR.parent / target
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered, encoding="utf-8", newline="\n")
    compact = [dict((key, value) for key, value in item.items() if key != "per_case") for item in results[:10]]
    print(json.dumps({"top": compact, "policy_count": len(results)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
