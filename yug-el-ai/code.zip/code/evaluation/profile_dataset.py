#!/usr/bin/env python3
"""Generate a bounded, reproducible profile of participant-facing inputs.

This development utility intentionally uses only the Python standard library. It
never mutates the dataset and never prints full financial rows.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import Counter, defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable


CSV_FILES = (
    "requests.csv",
    "sample_requests.csv",
    "financial_profiles.csv",
    "financial_events.csv",
    "exchange_rates.csv",
    "request_payment_options.csv",
    "messages.csv",
    "images.csv",
    "output.csv",
)

PRIMARY_KEYS = {
    "requests.csv": "request_id",
    "sample_requests.csv": "request_id",
    "financial_profiles.csv": "user_id",
    "financial_events.csv": "event_id",
    "request_payment_options.csv": "payment_option_id",
    "messages.csv": "message_id",
    "images.csv": "image_id",
}

DATE_COLUMNS = {
    "requests.csv": ("request_date", "desired_completion_date"),
    "sample_requests.csv": ("request_date", "desired_completion_date", "earliest_date_for_full_payment"),
    "financial_events.csv": ("event_date", "settlement_date"),
    "exchange_rates.csv": ("rate_date",),
    "request_payment_options.csv": ("first_payment_date",),
}


def parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-dir", type=Path, default=repo_root / "dataset")
    parser.add_argument("--output", type=Path, default=repo_root / "docs" / "contracts" / "dataset_profile.md")
    parser.add_argument(
        "--json-output",
        type=Path,
        default=repo_root / "docs" / "contracts" / "dataset_profile.json",
    )
    parser.add_argument("--check", action="store_true", help="Exit nonzero if reconciliation checks fail.")
    parser.add_argument("--stdout", action="store_true", help="Also print the Markdown report.")
    return parser.parse_args()


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"CSV has no header: {path}")
        rows = [{key: (value or "") for key, value in row.items()} for row in reader]
        return list(reader.fieldnames), rows


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bounded(values: Iterable[str], limit: int = 8) -> list[str]:
    return sorted({value for value in values if value})[:limit]


def distribution(rows: list[dict[str, str]], column: str) -> dict[str, int]:
    values = Counter((row.get(column, "") or "<blank>") for row in rows)
    return dict(sorted(values.items(), key=lambda item: (-item[1], item[0])))


def parse_decimal(value: str) -> Decimal | None:
    if not value.strip():
        return None
    try:
        return Decimal(value)
    except InvalidOperation:
        return None


def date_range(rows: list[dict[str, str]], column: str) -> dict[str, str | int | None]:
    parsed: list[date] = []
    invalid = 0
    for row in rows:
        value = row.get(column, "").strip()
        if not value:
            continue
        try:
            parsed.append(date.fromisoformat(value))
        except ValueError:
            invalid += 1
    return {
        "min": min(parsed).isoformat() if parsed else None,
        "max": max(parsed).isoformat() if parsed else None,
        "nonblank": len(parsed),
        "invalid": invalid,
    }


def find_cycles(parent_by_child: dict[str, str]) -> list[list[str]]:
    cycles: set[tuple[str, ...]] = set()
    for start in parent_by_child:
        positions: dict[str, int] = {}
        path: list[str] = []
        current = start
        while current and current in parent_by_child:
            if current in positions:
                cycle = path[positions[current] :]
                smallest = min(range(len(cycle)), key=lambda index: cycle[index])
                normalized = tuple(cycle[smallest:] + cycle[:smallest])
                cycles.add(normalized)
                break
            positions[current] = len(path)
            path.append(current)
            current = parent_by_child[current]
    return [list(item) for item in sorted(cycles)]


def profile(dataset_dir: Path) -> tuple[dict[str, Any], list[str]]:
    missing_files = [name for name in CSV_FILES if not (dataset_dir / name).is_file()]
    if missing_files:
        raise FileNotFoundError(f"Missing participant-facing CSVs: {', '.join(missing_files)}")

    headers: dict[str, list[str]] = {}
    tables: dict[str, list[dict[str, str]]] = {}
    files: dict[str, dict[str, Any]] = {}
    for name in CSV_FILES:
        path = dataset_dir / name
        headers[name], tables[name] = read_csv(path)
        rows = tables[name]
        files[name] = {
            "rows": len(rows),
            "columns": headers[name],
            "nulls": {column: sum(not row.get(column, "").strip() for row in rows) for column in headers[name]},
            "unique": {column: len({row.get(column, "") for row in rows if row.get(column, "").strip()}) for column in headers[name]},
            "sha256": sha256(path),
            "bytes": path.stat().st_size,
            "date_ranges": {
                column: date_range(rows, column) for column in DATE_COLUMNS.get(name, ())
            },
        }

    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, detail: str) -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    for name, key in PRIMARY_KEYS.items():
        rows = tables[name]
        values = [row[key] for row in rows]
        duplicates = [value for value, count in Counter(values).items() if value and count > 1]
        check(f"unique {key} in {name}", not duplicates, f"duplicates={bounded(duplicates)}")

    requests = tables["requests.csv"]
    samples = tables["sample_requests.csv"]
    profiles = tables["financial_profiles.csv"]
    events = tables["financial_events.csv"]
    options = tables["request_payment_options.csv"]
    messages = tables["messages.csv"]
    images = tables["images.csv"]
    output = tables["output.csv"]
    rates = tables["exchange_rates.csv"]

    request_ids = {row["request_id"] for row in requests}
    sample_ids = {row["request_id"] for row in samples}
    all_request_ids = request_ids | sample_ids
    profile_ids = {row["user_id"] for row in profiles}
    event_by_id = {row["event_id"]: row for row in events}
    event_ids = set(event_by_id)
    profile_by_user = {row["user_id"]: row for row in profiles}

    missing_eval_profiles = [row["request_id"] for row in requests if row["user_id"] not in profile_ids]
    missing_sample_profiles = [row["request_id"] for row in samples if row["user_id"] not in profile_ids]
    check("evaluation request profile coverage", not missing_eval_profiles, f"missing={bounded(missing_eval_profiles)}")
    check("sample request profile coverage", not missing_sample_profiles, f"missing={bounded(missing_sample_profiles)}")

    output_ids = [row["request_id"] for row in output]
    check(
        "output template IDs match evaluation requests",
        set(output_ids) == request_ids and len(output_ids) == len(requests),
        f"missing={bounded(request_ids - set(output_ids))}; extra={bounded(set(output_ids) - request_ids)}",
    )

    option_counts = Counter(row["request_id"] for row in options)
    invalid_option_refs = [row["payment_option_id"] for row in options if row["request_id"] not in all_request_ids]
    invalid_option_cardinality = [
        request_id for request_id in all_request_ids if not 2 <= option_counts.get(request_id, 0) <= 4
    ]
    check("payment option request links", not invalid_option_refs, f"invalid={bounded(invalid_option_refs)}")
    check("two-to-four options per request", not invalid_option_cardinality, f"invalid={bounded(invalid_option_cardinality)}")

    request_amount_by_id = {
        row["request_id"]: parse_decimal(row["requested_amount"]) for row in requests + samples
    }
    option_schedule_mismatch: list[str] = []
    option_fee_mismatch: list[str] = []
    for row in options:
        payment = parse_decimal(row["payment_amount"])
        count = parse_decimal(row["number_of_payments"])
        total = parse_decimal(row["total_payable_amount"])
        fee = parse_decimal(row["financing_fee"])
        request_amount = request_amount_by_id.get(row["request_id"])
        if None in (payment, count, total):
            option_schedule_mismatch.append(row["payment_option_id"])
        elif abs(payment * count - total) > Decimal("0.02"):
            option_schedule_mismatch.append(row["payment_option_id"])
        if None in (total, fee, request_amount):
            option_fee_mismatch.append(row["payment_option_id"])
        elif abs(request_amount + fee - total) > Decimal("0.02"):
            option_fee_mismatch.append(row["payment_option_id"])
    check("payment option schedule arithmetic", not option_schedule_mismatch, f"invalid={bounded(option_schedule_mismatch)}")
    check("payment option fee arithmetic", not option_fee_mismatch, f"invalid={bounded(option_fee_mismatch)}")

    invalid_message_users = [row["message_id"] for row in messages if row["user_id"] not in profile_ids]
    invalid_message_requests = [
        row["message_id"] for row in messages if row["request_id"] and row["request_id"] not in all_request_ids
    ]
    invalid_message_events = [
        row["message_id"] for row in messages if row["related_event_id"] and row["related_event_id"] not in event_ids
    ]
    check("message user links", not invalid_message_users, f"invalid={bounded(invalid_message_users)}")
    check("message request links", not invalid_message_requests, f"invalid={bounded(invalid_message_requests)}")
    check("message event links", not invalid_message_events, f"invalid={bounded(invalid_message_events)}")

    invalid_image_users = [row["image_id"] for row in images if row["user_id"] not in profile_ids]
    invalid_image_requests = [
        row["image_id"] for row in images if row["request_id"] and row["request_id"] not in all_request_ids
    ]
    invalid_image_events = [
        row["image_id"] for row in images if row["related_event_id"] and row["related_event_id"] not in event_ids
    ]
    image_files = {path.stem for path in (dataset_dir / "media" / "images").glob("*.png")}
    missing_image_files = [row["image_id"] for row in images if row["image_id"] not in image_files]
    extra_image_files = sorted(image_files - {row["image_id"] for row in images})
    check("image user links", not invalid_image_users, f"invalid={bounded(invalid_image_users)}")
    check("image request links", not invalid_image_requests, f"invalid={bounded(invalid_image_requests)}")
    check("image event links", not invalid_image_events, f"invalid={bounded(invalid_image_events)}")
    check("image index files exist", not missing_image_files, f"missing={bounded(missing_image_files)}")

    blank_events = [row for row in events if not row["amount"].strip()]
    images_by_event: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in images:
        if row["related_event_id"]:
            images_by_event[row["related_event_id"]].append(row)
    blank_without_one_image = [
        row["event_id"] for row in blank_events if len(images_by_event.get(row["event_id"], [])) != 1
    ]
    check("blank event amounts have exactly one linked image", not blank_without_one_image, f"invalid={bounded(blank_without_one_image)}")

    linked_events = [row for row in events if row["linked_event_id"]]
    missing_linked_parents = [row["event_id"] for row in linked_events if row["linked_event_id"] not in event_ids]
    cross_user_links = [
        row["event_id"]
        for row in linked_events
        if row["linked_event_id"] in event_by_id
        and event_by_id[row["linked_event_id"]]["user_id"] != row["user_id"]
    ]
    parent_by_child = {row["event_id"]: row["linked_event_id"] for row in linked_events}
    cycles = find_cycles(parent_by_child)
    child_counts = Counter(row["linked_event_id"] for row in linked_events)
    multi_child_parents = [event_id for event_id, count in child_counts.items() if count > 1]
    check("lifecycle parent links", not missing_linked_parents, f"missing={bounded(missing_linked_parents)}")
    check("lifecycle links stay within user", not cross_user_links, f"invalid={bounded(cross_user_links)}")
    check("lifecycle graph is acyclic", not cycles, f"cycles={cycles[:3]}")

    event_signature_counts = Counter(
        (
            row["user_id"],
            row["event_type"],
            row["description"],
            row["category"],
            row["direction"],
            row["amount"],
            row["currency"],
            row["event_date"],
            row["settlement_date"],
            row["status"],
        )
        for row in events
    )
    exact_duplicate_groups = sum(1 for count in event_signature_counts.values() if count > 1)

    rate_keys = {(row["rate_date"], row["from_currency"], row["to_currency"]) for row in rates}
    foreign_events = []
    missing_rate_events = []
    for row in events:
        profile_row = profile_by_user.get(row["user_id"])
        home = profile_row["home_currency"] if profile_row else ""
        if home and row["currency"] and row["currency"] != home and row["direction"] != "non_cash":
            foreign_events.append(row)
            rate_date = row["settlement_date"] or row["event_date"]
            if not rate_date or (rate_date, row["currency"], home) not in rate_keys:
                missing_rate_events.append(row["event_id"])
    check("dated FX coverage for foreign cash events", not missing_rate_events, f"missing={bounded(missing_rate_events)}")

    sample_users = {row["user_id"] for row in samples}
    sample_messages = [row for row in messages if row["user_id"] in sample_users]
    sample_images = [row for row in images if row["user_id"] in sample_users]

    profile_data: dict[str, Any] = {
        "schema_version": 1,
        "dataset_dir": str(dataset_dir.resolve()),
        "files": files,
        "counts": {
            "evaluation_requests": len(requests),
            "solved_samples": len(samples),
            "profiles": len(profiles),
            "financial_events": len(events),
            "exchange_rates": len(rates),
            "payment_options": len(options),
            "messages": len(messages),
            "images_indexed": len(images),
            "png_files": len(image_files),
            "blank_event_amounts": len(blank_events),
            "linked_events": len(linked_events),
            "foreign_cash_events": len(foreign_events),
        },
        "distributions": {
            "request_type": distribution(requests, "request_type"),
            "allows_partial_payment": distribution(requests, "allows_partial_payment"),
            "profile_home_currency": distribution(profiles, "home_currency"),
            "profile_payment_methods": distribution(profiles, "payment_methods_user_will_consider"),
            "event_type": distribution(events, "event_type"),
            "event_status": distribution(events, "status"),
            "event_direction": distribution(events, "direction"),
            "event_flexibility": distribution(events, "flexibility"),
            "event_currency": distribution(events, "currency"),
            "payment_method": distribution(options, "payment_method"),
            "payment_count": distribution(options, "number_of_payments"),
            "options_per_request": dict(sorted(Counter(option_counts.values()).items())),
            "message_source": distribution(messages, "source_type"),
            "sample_status": distribution(samples, "affordability_status"),
            "sample_method": distribution(samples, "recommended_payment_method"),
        },
        "join_coverage": {
            "evaluation_requests_with_profile": len(requests) - len(missing_eval_profiles),
            "sample_requests_with_profile": len(samples) - len(missing_sample_profiles),
            "options_with_valid_request": len(options) - len(invalid_option_refs),
            "messages_with_request_link": sum(bool(row["request_id"]) for row in messages),
            "messages_with_event_link": sum(bool(row["related_event_id"]) for row in messages),
            "images_with_event_link": sum(bool(row["related_event_id"]) for row in images),
            "blank_events_with_exactly_one_image": len(blank_events) - len(blank_without_one_image),
            "sample_linked_messages": len(sample_messages),
            "sample_linked_images": len(sample_images),
        },
        "lifecycle": {
            "linked_rows": len(linked_events),
            "missing_parents": len(missing_linked_parents),
            "cross_user_links": len(cross_user_links),
            "cycles": len(cycles),
            "parents_with_multiple_children": len(multi_child_parents),
            "bounded_multi_child_parent_ids": bounded(multi_child_parents),
        },
        "suspicious": {
            "exact_duplicate_event_groups": exact_duplicate_groups,
            "extra_png_files": extra_image_files[:8],
            "option_schedule_mismatches": bounded(option_schedule_mismatch),
            "option_fee_mismatches": bounded(option_fee_mismatch),
            "missing_rate_events": bounded(missing_rate_events),
        },
        "bounded_ids": {
            "blank_amount_events": bounded((row["event_id"] for row in blank_events), limit=20),
            "sample_message_ids": bounded(row["message_id"] for row in sample_messages),
            "sample_image_ids": bounded(row["image_id"] for row in sample_images),
        },
        "checks": checks,
    }
    failures = [item["name"] for item in checks if not item["passed"]]
    return profile_data, failures


def format_counter(counter: dict[str, int]) -> str:
    return ", ".join(f"`{key}`: {value}" for key, value in counter.items())


def markdown(profile_data: dict[str, Any]) -> str:
    counts = profile_data["counts"]
    files = profile_data["files"]
    dist = profile_data["distributions"]
    joins = profile_data["join_coverage"]
    lifecycle = profile_data["lifecycle"]
    suspicious = profile_data["suspicious"]
    checks = profile_data["checks"]
    lines = [
        "# Dataset Profile",
        "",
        "> Generated by `python code/evaluation/profile_dataset.py --check`. The utility reads participant-facing inputs only and emits bounded summaries.",
        "",
        "## Inventory",
        "",
        "| File | Rows | Columns | Bytes | SHA-256 |",
        "|---|---:|---:|---:|---|",
    ]
    for name in CSV_FILES:
        info = files[name]
        lines.append(f"| `{name}` | {info['rows']} | {len(info['columns'])} | {info['bytes']} | `{info['sha256']}` |")
    lines.extend(
        [
            "",
            f"PNG media: **{counts['png_files']} files**. Indexed images: **{counts['images_indexed']}**.",
            "",
            "## Core counts",
            "",
            f"- Evaluation requests: **{counts['evaluation_requests']}**; solved samples: **{counts['solved_samples']}**; profiles: **{counts['profiles']}**.",
            f"- Financial events: **{counts['financial_events']}**; payment options: **{counts['payment_options']}**; exchange rates: **{counts['exchange_rates']}**.",
            f"- Messages: **{counts['messages']}**; linked-event rows: **{counts['linked_events']}**; blank event amounts: **{counts['blank_event_amounts']}**.",
            f"- Foreign-currency cash events requiring dated conversion: **{counts['foreign_cash_events']}**.",
            "",
            "## Distributions",
            "",
            f"- Evaluation request types — {format_counter(dist['request_type'])}",
            f"- Partial payment permission — {format_counter(dist['allows_partial_payment'])}",
            f"- Home currencies — {format_counter(dist['profile_home_currency'])}",
            f"- Event statuses — {format_counter(dist['event_status'])}",
            f"- Event types — {format_counter(dist['event_type'])}",
            f"- Event directions — {format_counter(dist['event_direction'])}",
            f"- Event flexibility — {format_counter(dist['event_flexibility'])}",
            f"- Payment methods — {format_counter(dist['payment_method'])}",
            f"- Options per request — {format_counter({str(key): value for key, value in dist['options_per_request'].items()})}",
            f"- Message sources — {format_counter(dist['message_source'])}",
            f"- Solved-sample status — {format_counter(dist['sample_status'])}",
            f"- Solved-sample method — {format_counter(dist['sample_method'])}",
            "",
            "## Join and evidence coverage",
            "",
            f"- Evaluation requests with profiles: **{joins['evaluation_requests_with_profile']}/{counts['evaluation_requests']}**.",
            f"- Sample requests with profiles: **{joins['sample_requests_with_profile']}/{counts['solved_samples']}**.",
            f"- Payment options linked to known requests: **{joins['options_with_valid_request']}/{counts['payment_options']}**.",
            f"- Messages with request links: **{joins['messages_with_request_link']}**; with direct event links: **{joins['messages_with_event_link']}**.",
            f"- Images with event links: **{joins['images_with_event_link']}**; blank amounts with exactly one linked image: **{joins['blank_events_with_exactly_one_image']}/{counts['blank_event_amounts']}**.",
            f"- Evidence touching solved-sample users: **{joins['sample_linked_messages']} messages** and **{joins['sample_linked_images']} images**.",
            "",
            "## Date ranges",
            "",
            "| File.column | Minimum | Maximum | Nonblank | Invalid |",
            "|---|---|---|---:|---:|",
        ]
    )
    for name in CSV_FILES:
        for column, info in files[name]["date_ranges"].items():
            lines.append(
                f"| `{name}.{column}` | {info['min'] or '—'} | {info['max'] or '—'} | {info['nonblank']} | {info['invalid']} |"
            )
    lines.extend(
        [
            "",
            "## Null counts",
            "",
            "Blank optional fields dominate several tables and must retain semantic meaning; a blank amount is never interpreted as zero.",
            "",
            "| File | Nonzero blank counts |",
            "|---|---|",
        ]
    )
    for name in CSV_FILES:
        nonzero = {key: value for key, value in files[name]["nulls"].items() if value}
        lines.append(f"| `{name}` | {format_counter(nonzero) if nonzero else 'none'} |")
    lines.extend(
        [
            "",
            "## Key cardinality",
            "",
            "Complete per-column nonblank cardinalities are stored in `dataset_profile.json`; these are the identifiers and joins used by the pipeline.",
            "",
            "| File.column | Unique nonblank values | Rows |",
            "|---|---:|---:|",
        ]
    )
    key_columns = {
        "requests.csv": ("request_id", "user_id"),
        "sample_requests.csv": ("request_id", "user_id"),
        "financial_profiles.csv": ("user_id",),
        "financial_events.csv": ("event_id", "user_id", "linked_event_id"),
        "exchange_rates.csv": ("rate_date", "from_currency", "to_currency"),
        "request_payment_options.csv": ("payment_option_id", "request_id"),
        "messages.csv": ("message_id", "user_id", "request_id", "related_event_id"),
        "images.csv": ("image_id", "user_id", "request_id", "related_event_id"),
        "output.csv": ("request_id",),
    }
    for name, columns in key_columns.items():
        for column in columns:
            lines.append(f"| `{name}.{column}` | {files[name]['unique'][column]} | {files[name]['rows']} |")
    lines.extend(
        [
            "",
            "## Lifecycle and suspicious-record inventory",
            "",
            f"- Linked lifecycle rows: **{lifecycle['linked_rows']}**; missing parents: **{lifecycle['missing_parents']}**; cross-user links: **{lifecycle['cross_user_links']}**; cycles: **{lifecycle['cycles']}**.",
            f"- Lifecycle parents with multiple children: **{lifecycle['parents_with_multiple_children']}**; bounded IDs: `{lifecycle['bounded_multi_child_parent_ids']}`.",
            f"- Exact duplicate event-signature groups: **{suspicious['exact_duplicate_event_groups']}**. These are discovery signals, not automatic cash-flow exclusions.",
            f"- Extra unindexed PNGs: `{suspicious['extra_png_files']}`.",
            f"- Option schedule arithmetic mismatches: `{suspicious['option_schedule_mismatches']}`.",
            f"- Option fee arithmetic mismatches: `{suspicious['option_fee_mismatches']}`.",
            f"- Foreign cash events without a dated rate: `{suspicious['missing_rate_events']}`.",
            "",
            "## Reconciliation checks",
            "",
            "| Check | Result | Detail |",
            "|---|---|---|",
        ]
    )
    for item in checks:
        result = "PASS" if item["passed"] else "FAIL"
        detail = str(item["detail"]).replace("|", "\\|")
        lines.append(f"| {item['name']} | **{result}** | `{detail}` |")
    lines.extend(
        [
            "",
            "## Phase 01 interpretation",
            "",
            "- Each request has a dedicated user profile, but historical ledgers are dense enough that recurrence inference—not input joining—is the primary modeling risk.",
            "- Evidence is sparse and high impact: every blank amount is image-linked, and messages can change cash state, timing, recurrence, or duplication semantics.",
            "- Payment offers are structurally regular but include long schedules that may violate a request deadline or user installment limit; availability does not imply eligibility.",
            "- Linked rows and exact duplicates require a lifecycle resolver before cash forecasting. This report intentionally does not decide their financial meaning.",
        ]
    )
    return "\n".join(lines) + "\n"


def atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8", newline="\n")
    temporary.replace(path)


def main() -> int:
    args = parse_args()
    try:
        profile_data, failures = profile(args.dataset_dir.resolve())
        report = markdown(profile_data)
        atomic_write(args.output.resolve(), report)
        atomic_write(args.json_output.resolve(), json.dumps(profile_data, indent=2, sort_keys=True) + "\n")
    except (FileNotFoundError, ValueError, OSError, KeyError) as error:
        print(f"profile error: {error}", file=sys.stderr)
        return 2

    if args.stdout:
        print(report, end="")
    print(
        f"profiled {profile_data['counts']['evaluation_requests']} evaluation requests; "
        f"wrote {args.output} and {args.json_output}"
    )
    if args.check and failures:
        print(f"reconciliation checks failed: {', '.join(failures)}", file=sys.stderr)
        return 1
    print(f"reconciliation checks: {len(profile_data['checks']) - len(failures)} passed, {len(failures)} failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
