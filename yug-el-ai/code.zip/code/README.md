# Buy or Wait / Cushion

Submission release: complete offline request-to-decision pipeline. All 16 mandatory blank amounts have a local OCR resolution path. Use RapidOCR for the reproducible final run; no API key or paid service is required. See ARCHITECTURE.md and evaluation/usage_report.md for limitations and final-run accounting.

## Clean extracted package: quick start

The archive contains a top-level `code/` directory. Run commands from the directory containing it. Keep the organizer dataset separate and pass its absolute path.

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r code/requirements-ocr.txt
& .\.venv\Scripts\python.exe code/main.py --dataset-dir "C:\path\to\dataset" --generate-output --ocr rapidocr
& .\.venv\Scripts\python.exe code/main.py --dataset-dir "C:\path\to\dataset" --validate-output output.csv --ocr rapidocr
```

POSIX:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r code/requirements-ocr.txt
.venv/bin/python code/main.py --dataset-dir /absolute/path/to/dataset --generate-output --ocr rapidocr
.venv/bin/python code/main.py --dataset-dir /absolute/path/to/dataset --validate-output output.csv --ocr rapidocr
```

Input validation: add `--validate-inputs` instead of `--generate-output`. Public evaluation: `python code/evaluation/decision_gate.py --dataset-dir /absolute/path/to/dataset --samples-only --ocr rapidocr`. Redacted trace: `python code/main.py --dataset-dir /absolute/path/to/dataset --decision-trace REQUEST_ID --ocr rapidocr` using an ID from the supplied file.

Portable critical tests (no dataset required): `python -m unittest discover -s code/tests -t code -p test_forecast.py`; replace the pattern with `test_money.py`, `test_models.py`, or `test_serialization.py`. Full development tests additionally expect the original repository's dataset and project-state documentation. Packaged schema documentation is under code/docs/contracts/schemas. Reproduction plus independent serialized-plan validation: `python code/evaluation/release_verify.py --dataset-dir /absolute/path/to/dataset --output /absolute/path/to/reproduced.csv --report /absolute/path/to/report.json`.

The active roadmap is submission-only: Phase 07 completes planning, explanations, and CSV generation; Phase 08 calibrates and hardens accuracy; Phase 09 produces and verifies `output.csv`, `code.zip`, the usage report, and transcript. Frontend, API, database, hosted deployment, and plugin work are deferred.

Requires Python 3.12 or newer. Input validation and deterministic message extraction use only the standard library. OCR is optional; a request with a mandatory unreadable image fails explicitly when no capable provider is available. No API key is needed for the offline path.

From the repository root:

```text
python code/main.py --validate-inputs
python code/main.py --profile-inputs
python -m unittest discover -s code/tests -t code -v
python code/evaluation/profile_dataset.py --check
```

From an extracted code package, supply the participant dataset explicitly:

```text
python main.py --dataset-dir /absolute/path/to/dataset --validate-inputs
```

An absolute CLI script path works from any working directory. Relative `--dataset-dir` values resolve against the repository root (or the extracted package root when `main.py` is at that root), not the current shell directory. Windows accepts normal absolute drive paths.

If Python is not installed on PATH in the current Codex desktop environment, the verified local runtime is:

```powershell
& 'C:\Users\yokri\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' code/main.py --validate-inputs
```

That path is a local convenience, not a runtime dependency. Use your own Python 3.12+ interpreter on other machines.

The CLI exits 0 after successful diagnostics, 2 after invalid inputs, 3 for an explicitly unresolved traced request/provider configuration, and 4 for an invalid prediction CSV. Errors identify files/rows or request/event IDs; summaries exclude private financial text. All participant inputs are read-only.

## Final decisions and prediction CSV

```text
python code/main.py --decision-trace request_01 --ocr rapidocr
python code/main.py --generate-output --ocr rapidocr
python code/main.py --validate-output output.csv --ocr rapidocr
python code/evaluation/decision_gate.py --ocr rapidocr --samples-only
python code/evaluation/decision_gate.py --ocr rapidocr --report docs/contracts/decision_profile.json --write-output output.csv
```

The production service enumerates full, partial, supplied installment, wait, and permitted spending-change candidates. The deterministic 91-day simulator is the only safety oracle; an independent validator replays the final selected plan. Candidate ranking follows the challenge order exactly. Output is written atomically outside `dataset/`, and the decision trace redacts financial amounts while retaining rejection reasons and fingerprints.

Final output uses the frozen Phase 08 policy. The ingestion context can hold public expectations for evaluation, but the production decision service does not access them or contain request-specific answers.

## Forecast commands

```text
python code/main.py --forecast-trace request_20
python code/main.py --forecast-user-trace user_20
python code/evaluation/forecast_gate.py --ocr rapidocr --report docs/contracts/forecast_profile.json
```

Forecast traces are amount-redacted and request-scoped. They show the inclusive 91-day boundary, recurrence cadence/strategy counts, bounded source provenance, unresolved evidence, earliest safe full-payment date, tightest day, violations, and deterministic fingerprints. The full gate checks all 250 evaluation requests plus all 25 public samples without putting sample answers in runtime code. It uses local OCR only and makes no paid-model or network call.

## Canonical ledger commands

```text
python code/main.py --ledger-trace request_20
python code/main.py --ledger-user-trace user_20
python code/evaluation/ledger_gate.py --ocr none
python code/evaluation/ledger_gate.py --ocr rapidocr --report docs/contracts/ledger_profile.json
```

Ledger traces are amount-free and request-scoped. They show one disposition per event, lifecycle resolutions, explicit future-flow counts, exclusions, warnings and invariant checks. Exit code `3` means the target contains unresolved mandatory financial evidence; no blank amount is treated as zero. The full gate covers evaluation and sample contexts without reading expected sample outputs in runtime code.

Development contracts and handoffs live under the repository's `docs/` folder. The final packaging phase must carry the documentation/schema artifacts needed by the finished submission into `code.zip`; participant data remains excluded.

## Evidence commands

```text
python code/main.py --evidence-preflight
python code/main.py --evidence-trace request_20
python code/main.py --evidence-preflight --ocr none --no-evidence-cache
python code/evaluation/evidence_gate.py --report docs/contracts/evidence_profile.json
```

These commands do not generate affordability predictions. Preflight includes all 250 evaluation requests and 25 public samples. Public sample PNGs are used as extraction fixtures only outside production code. All 16 blank amounts resolve with the verified local RapidOCR configuration, including a generic multi-crop consensus fallback for the handwritten amount.

## Optional portable OCR

```text
python -m venv .venv
.venv/Scripts/python -m pip install -r code/requirements-ocr.txt
.venv/Scripts/python code/evaluation/evidence_gate.py --report docs/contracts/evidence_profile.json
```

On Linux/macOS use `.venv/bin/python`. Installation needs package-download access once; extraction itself is local. The Windows/Python 3.12 reproduction snapshot is `evaluation/ocr-environment-win-py312.lock.txt`. Auto selection prefers installed RapidOCR, then Windows OCR, then Tesseract. Select explicitly with `--ocr rapidocr`, `windows`, `tesseract`, or `none`. Different engines have different accuracy; do not assume equivalent gate results.

Windows OCR requires an installed language pack and uses a fixed helper with process-scoped `-ExecutionPolicy Bypass`; it does not change machine policy. Tesseract is an optional executable on PATH. Pillow enables development crop probes and is installed with RapidOCR. No provider SDK is required for the base package.

For the complete local integration suite in PowerShell:

```powershell
$env:BUYWAIT_TEST_LOCAL_OCR='1'
.\.venv\Scripts\python.exe -m unittest discover -s code/tests -t code -v
```

Without that opt-in, the two local OCR integration tests are skipped. The remaining tests need no optional dependency or network.

## Optional remote evidence (off by default)

Enable only after choosing a model, reviewing data-sharing/cost, and setting these environment variables locally:

- `OPENAI_API_KEY`: credential; never put it in source, logs or the transcript.
- `BUYWAIT_EVIDENCE_MODEL`: explicit model name supporting images and strict Structured Outputs.
- `BUYWAIT_INPUT_USD_PER_MILLION`, `BUYWAIT_OUTPUT_USD_PER_MILLION`: verified prices for that model. There is no fabricated default price.

```text
python code/main.py --evidence-trace request_101 --evidence-model openai
```

This sends only that request's relevant evidence to OpenAI. It is an explicit opt-in and can incur cost. The adapter cannot call tools, choose file paths, set environment variables, or emit affordability decisions. It has strict validation, timeouts and one retry for explicit transient HTTP errors; uncertain timeouts are not replayed automatically. The official schema lives in runtime `buywait/evidence/model_contract.py`; public documentation is in the repository schema folder.

Every attempted call is appended to ignored `audit/evidence-usage.jsonl`. Override with `--evidence-usage-log`. Unknown usage after a failure is labeled `extract_usage_unknown`; never count it as a known free call in the final report. `evaluation/usage_report.md` must describe the actual final prediction run later, not these development checks.

The generated `.cache/evidence/` stores controlled facts, hashes, provenance, confidence, original usage and latency. Raw OCR text/boxes remain in memory only. `--no-evidence-cache` bypasses cache; `--evidence-cache-dir` chooses a repository-relative or absolute private cache directory. Cache files are **not submission-approved** and must not be hand-edited or packaged without review.
