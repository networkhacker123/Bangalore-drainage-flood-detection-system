"""Small synthetic corpus. No supplied financial rows or sample labels are copied."""

import csv
from pathlib import Path

from buywait.adapters.dataset.schema import HEADERS

PNG = b"\x89PNG\r\n\x1a\n" + b"synthetic-image-body"


def corpus() -> dict[str, list[dict[str, str]]]:
    def row(filename: str, **values: str) -> dict[str, str]:
        result = dict.fromkeys(HEADERS[filename], "")
        result.update(values)
        return result

    profiles = [row("financial_profiles.csv", user_id=user, home_currency=currency,
                    current_available_balance="1000.10", minimum_balance_to_keep="100",
                    financial_priorities="education", expense_categories_to_protect="rent|groceries",
                    expense_categories_user_is_willing_to_reduce="dining",
                    payment_methods_user_will_consider="full_payment|installments", max_installment_months="3")
                for user, currency in (("user_A", "USD"), ("user_B", "EUR"))]
    requests = [row("requests.csv", request_id=req, user_id=user, request_date="2026-09-12",
                    request_type="purchase", requested_amount="100", desired_completion_date="2026-12-01",
                    allows_partial_payment="false", request_text="Private synthetic request")
                for req, user in (("req_A", "user_A"), ("req_B", "user_B"))]
    sample = row("sample_requests.csv", **{**requests[0], "request_id": "sample_A"},
                 amount_safe_to_pay="100", affordability_status="affordable_now",
                 recommended_payment_method="full_payment", payment_plan="2026-09-12:100",
                 earliest_date_for_full_payment="2026-09-12", spending_changes_needed="none",
                 decision_explanation="Private synthetic sample explanation")
    options = []
    for request in requests + [sample]:
        for suffix, method, amount, count, frequency in (
            ("full", "full_payment", "100", "1", ""), ("installments", "installments", "50", "2", "30"),
        ):
            options.append(row("request_payment_options.csv", payment_option_id=request["request_id"] + "_" + suffix,
                               request_id=request["request_id"], payment_method=method, payment_amount=amount,
                               number_of_payments=count, first_payment_date="2026-09-12",
                               payment_frequency_days=frequency, financing_fee="0", total_payable_amount="100"))
    return {
        "financial_profiles.csv": profiles, "requests.csv": requests, "sample_requests.csv": [sample],
        "financial_events.csv": [
            row("financial_events.csv", event_id="event_A", user_id="user_A", event_type="expense",
                description="Private expense", category="groceries", direction="debit", currency="EUR",
                event_date="2026-09-10", settlement_date="2026-09-11", status="settled", flexibility="fixed"),
            row("financial_events.csv", event_id="event_B", user_id="user_B", event_type="expense",
                description="Private expense B", category="groceries", direction="debit", amount="8.001",
                currency="EUR", event_date="2026-09-10", settlement_date="2026-09-11", status="settled", flexibility="fixed"),
        ],
        "exchange_rates.csv": [row("exchange_rates.csv", rate_date="2026-09-11", from_currency="EUR", to_currency="USD", rate="1.2345")],
        "request_payment_options.csv": options,
        "messages.csv": [row("messages.csv", message_id=identifier, user_id="user_A", request_id=request_id,
                             related_event_id=event_id, sent_at="2026-09-11T09:30:00Z", source_type="merchant",
                             message_text="Private message: secret-marker-987")
                         for identifier, request_id, event_id in (
                             ("msg_user", "", ""), ("msg_event", "sample_A", "event_A"),
                             ("msg_request", "req_A", ""), ("msg_other_request", "sample_A", ""),
                         )],
        "images.csv": [row("images.csv", image_id=identifier, user_id="user_A", request_id=request_id, related_event_id=event_id)
                       for identifier, request_id, event_id in (
                           ("image_event", "req_A", "event_A"), ("image_other_request", "sample_A", ""), ("image_user", "", ""),
                       )],
        "output.csv": [row("output.csv", request_id=request["request_id"]) for request in requests],
    }


def materialize(root: Path, tables: dict[str, list[dict[str, str]]], *, omitted_images: tuple[str, ...] = ()) -> None:
    root.mkdir(parents=True, exist_ok=True)
    for filename, rows in tables.items():
        with (root / filename).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=HEADERS[filename], lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
    media = root / "media" / "images"
    media.mkdir(parents=True, exist_ok=True)
    for row in tables["images.csv"]:
        if row["image_id"] not in omitted_images and "/" not in row["image_id"] and "\\" not in row["image_id"]:
            (media / (row["image_id"] + ".png")).write_bytes(PNG)
