from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal
import json
import unittest

from buywait.domain.enums import (
    AmountStrategy,
    CashState,
    Currency,
    Direction,
    EvidenceFactType,
    EvidenceSourceKind,
    Flexibility,
    ForecastOrigin,
    RecurrenceCadence,
    SpendingChangeAction,
    ViolationCode,
)
from buywait.domain.models import (
    CanonicalCashFlow,
    CanonicalLedger,
    DateRange,
    EvidenceFact,
    EvidenceProvenance,
    ForecastOccurrence,
    ForecastTimeline,
    HistoricalSeriesCandidate,
    Payment,
    RecurrenceRule,
    SpendingChange,
)
from buywait.domain.money import Money
from buywait.forecasting import ForecastEngine, ForecastSimulator, ForecastTimelineBuilder, RecurrenceDetector
from buywait.forecasting.trace import redacted_forecast_trace
from buywait.forecasting.policy import PHASE07_BASELINE_POLICY, RELEASE_CANDIDATE_POLICY


USD = Currency.USD
ZERO_HASH = "0" * 64


def money(value):
    return Money(Decimal(str(value)), USD)


def flow(flow_id, when, amount, direction=Direction.DEBIT, category="rent", *,
         state=CashState.HISTORICAL, protected=True, flexibility=Flexibility.FIXED,
         event_id=None):
    return CanonicalCashFlow(
        flow_id, "user_A", when, money(amount), direction, category, category,
        state, (event_id or flow_id.replace("flow_", "event_"),),
        protected=protected, flexibility=flexibility,
    )


def ledger(flows, *, as_of=date(2026, 4, 1), balance="1000", floor="200", series=()):
    return CanonicalLedger(
        "request_A", "user_A", as_of, USD, money(balance), money(floor),
        tuple(sorted(flows, key=lambda item: (item.effective_date, item.flow_id))),
        (), (), (), tuple(series), (), ZERO_HASH,
    )


def timeline(occurrences, *, start=date(2026, 4, 1), rules=(), unresolved=()):
    return ForecastTimeline(
        "request_A", "user_A", USD, DateRange(start, date.fromordinal(start.toordinal() + 90)),
        tuple(rules), tuple(sorted(occurrences, key=lambda item: (item.flow.effective_date, item.flow.flow_id))),
        tuple(unresolved), ZERO_HASH,
    )


class RecurrenceTests(unittest.TestCase):
    def test_single_observation_is_not_inferred(self):
        item = flow("flow_1", date(2026, 3, 31), "100")
        series = HistoricalSeriesCandidate("series_1", "user_A", "rent", Direction.DEBIT, (item.flow_id,))
        self.assertEqual(RecurrenceDetector().infer(ledger((item,), series=(series,))), ())

    def test_month_end_short_month_and_fixed_latest(self):
        rows = (
            flow("flow_1", date(2025, 12, 31), "100"),
            flow("flow_2", date(2026, 1, 31), "110"),
            flow("flow_3", date(2026, 2, 28), "120"),
            flow("flow_4", date(2026, 3, 31), "130"),
        )
        series = HistoricalSeriesCandidate(
            "series_1", "user_A", "rent", Direction.DEBIT, tuple(item.flow_id for item in rows)
        )
        base = ledger(rows, series=(series,))
        rules = RecurrenceDetector().infer(base)
        self.assertEqual(len(rules), 1)
        self.assertEqual(rules[0].cadence, RecurrenceCadence.MONTHLY)
        self.assertTrue(rules[0].end_of_month)
        self.assertEqual(rules[0].amount_strategy, AmountStrategy.LATEST)
        self.assertEqual(rules[0].amount.amount, Decimal("130"))
        generated = ForecastTimelineBuilder().build(base).occurrences
        self.assertEqual(generated[0].flow.effective_date, date(2026, 4, 30))

    def test_protected_variable_essential_uses_recent_p75(self):
        rows = tuple(
            flow(f"flow_g{index}", date(2026, 3, 1 + 7 * index), amount,
                 category="groceries")
            for index, amount in enumerate(("80", "100", "90", "110"))
        )
        series = HistoricalSeriesCandidate("series_g", "user_A", "groceries", Direction.DEBIT,
                                           tuple(item.flow_id for item in rows))
        rule = RecurrenceDetector().infer(ledger(rows, series=(series,)))[0]
        self.assertEqual(rule.amount_strategy, AmountStrategy.CONSERVATIVE_ROBUST)
        self.assertEqual(rule.amount.amount, Decimal("100"))

    def test_weekly_biweekly_and_custom_are_detected(self):
        for gap, expected in ((7, RecurrenceCadence.WEEKLY), (14, RecurrenceCadence.BIWEEKLY),
                              (10, RecurrenceCadence.CUSTOM_DAYS)):
            rows = tuple(flow(f"flow_{gap}_{index}", date(2026, 1, 1 + gap * index), "10",
                              category=f"category_{gap}") for index in range(3))
            series = HistoricalSeriesCandidate(
                f"series_{gap}", "user_A", f"category_{gap}", Direction.DEBIT,
                tuple(item.flow_id for item in rows),
            )
            rule = RecurrenceDetector().infer(ledger(rows, series=(series,)))[0]
            self.assertEqual(rule.cadence, expected)

    def test_confirmed_payroll_completes_two_point_monthly_evidence(self):
        historical = flow("flow_salary_1", date(2026, 2, 15), "900", Direction.CREDIT, "salary")
        future = flow("flow_salary_2", date(2026, 3, 15), "1000", Direction.CREDIT, "salary",
                      state=CashState.FUTURE_CONFIRMED)
        base = ledger((historical, future), as_of=date(2026, 3, 1))
        rules = RecurrenceDetector().infer(base)
        self.assertEqual(len(rules), 1)
        self.assertEqual(rules[0].amount.amount, Decimal("1000"))
        occurrences = ForecastTimelineBuilder().build(base).occurrences
        self.assertEqual([item.flow.effective_date for item in occurrences],
                         [date(2026, 3, 15), date(2026, 4, 15), date(2026, 5, 15)])

    def test_effective_salary_date_amendment_shifts_future_cadence(self):
        rows = tuple(flow(f"flow_s{month}", date(2026, month, 15), "1000", Direction.CREDIT, "salary")
                     for month in (1, 2, 3))
        series = HistoricalSeriesCandidate("series_s", "user_A", "salary", Direction.CREDIT,
                                           tuple(item.flow_id for item in rows))
        fact = EvidenceFact(
            "fact_shift", EvidenceFactType.SETTLEMENT_DATE, date(2026, 4, 23),
            EvidenceProvenance(EvidenceSourceKind.MESSAGE, "message_1", datetime.now(timezone.utc)),
            effective_date=date(2026, 4, 23), subject="salary", scope="recurring", explicit=True,
        )
        base = ledger(rows, as_of=date(2026, 4, 1), series=(series,))
        rule = RecurrenceDetector().infer(base, (fact,))[0]
        self.assertEqual(rule.anchor_date, date(2026, 4, 23))
        self.assertEqual(ForecastTimelineBuilder().build(base, (fact,)).occurrences[0].flow.effective_date,
                         date(2026, 5, 23))

    def test_next_cycle_salary_amendment_does_not_extend_latest_anomaly(self):
        rows = (
            flow("flow_s1", date(2025, 12, 15), "1000", Direction.CREDIT, "salary"),
            flow("flow_s2", date(2026, 1, 15), "1000", Direction.CREDIT, "salary"),
            flow("flow_s3", date(2026, 2, 15), "1000", Direction.CREDIT, "salary"),
            flow("flow_s4", date(2026, 3, 15), "600", Direction.CREDIT, "salary"),
        )
        series = HistoricalSeriesCandidate("series_s", "user_A", "salary", Direction.CREDIT,
                                           tuple(item.flow_id for item in rows))
        fact = EvidenceFact(
            "fact_temporary", EvidenceFactType.AMOUNT, Decimal("750"),
            EvidenceProvenance(EvidenceSourceKind.MESSAGE, "message_1", datetime.now(timezone.utc)),
            subject="salary", scope="next_cycle", explicit=True,
        )
        rule = RecurrenceDetector().infer(ledger(rows, series=(series,)), (fact,))[0]
        self.assertEqual(rule.amount_strategy, AmountStrategy.FIXED)
        self.assertEqual(rule.amount.amount, Decimal("1000"))

    def test_confirmed_payroll_allows_missing_historical_months(self):
        historical = tuple(
            flow(f"flow_s{index}", when, "1000", Direction.CREDIT, "salary")
            for index, when in enumerate((date(2026, 1, 15), date(2026, 2, 15), date(2026, 5, 15)), 1)
        )
        future = flow("flow_s4", date(2026, 6, 15), "1000", Direction.CREDIT, "salary",
                      state=CashState.FUTURE_CONFIRMED)
        series = HistoricalSeriesCandidate("series_s", "user_A", "salary", Direction.CREDIT,
                                           tuple(item.flow_id for item in historical))
        rules = RecurrenceDetector().infer(
            ledger((*historical, future), as_of=date(2026, 6, 1), series=(series,))
        )
        self.assertEqual(len(rules), 1)
        self.assertEqual(rules[0].cadence, RecurrenceCadence.MONTHLY)
        self.assertEqual(rules[0].interval, 1)


class SimulationTests(unittest.TestCase):
    def setUp(self):
        self.debit = flow("flow_due", date(2026, 4, 3), "100", state=CashState.FUTURE_RESERVED)
        self.credit = flow("flow_pay", date(2026, 4, 5), "300", Direction.CREDIT, "salary",
                           state=CashState.FUTURE_CONFIRMED)
        self.timeline = timeline((
            ForecastOccurrence(self.debit, ForecastOrigin.CANONICAL_FUTURE),
            ForecastOccurrence(self.credit, ForecastOrigin.CANONICAL_FUTURE),
        ))
        self.simulator = ForecastSimulator()

    def test_inclusive_boundaries_exact_math_and_determinism(self):
        first = self.simulator.simulate(self.timeline, money("1000.10"), money("200.10"))
        second = self.simulator.simulate(self.timeline, money("1000.10"), money("200.10"))
        self.assertEqual(len(first.days), 91)
        self.assertEqual(first.days[0].forecast_date, date(2026, 4, 1))
        self.assertEqual(first.days[-1].forecast_date, date(2026, 6, 30))
        self.assertEqual(first.fingerprint, second.fingerprint)
        self.assertEqual(first.days[-1].closing_balance.amount, Decimal("1200.10"))
        self.assertNotIn(".", type(first.days[-1].closing_balance.amount).__module__)

    def test_confirmed_same_day_credit_precedes_payment(self):
        result = self.simulator.simulate(
            self.timeline, money("1000"), money("200"),
            payments=(Payment(date(2026, 4, 5), money("801"), 1),),
        )
        self.assertTrue(result.safety_result.safe)

    def test_capacity_and_earliest_full_payment(self):
        assessment = ForecastEngine(
            timeline_builder=StaticTimelineBuilder(self.timeline)
        ).assess(ledger((), balance="1000", floor="200"), money("800"))
        self.assertEqual(assessment.amount_safe_to_pay.amount, Decimal("700"))
        self.assertEqual(assessment.earliest_date_for_full_payment, date(2026, 4, 5))

    def test_today_confirmed_credit_capacity_is_maximal_after_settlement(self):
        today = date(2026, 4, 1)
        credit = flow("flow_today", today, "300", Direction.CREDIT, "salary",
                      state=CashState.FUTURE_CONFIRMED)
        value = timeline((ForecastOccurrence(credit, ForecastOrigin.CANONICAL_FUTURE),))
        engine = ForecastEngine(StaticTimelineBuilder(value))
        assessment = engine.assess(ledger((), balance="200", floor="100"), money("500"))
        self.assertEqual(assessment.amount_safe_to_pay, money("400"))
        for amount, safe in (("400", True), ("400.01", False)):
            result = engine.simulator.simulate(value, money("200"), money("100"),
                payments=(Payment(today, money(amount), 1),))
            self.assertEqual(result.safety_result.safe, safe)
        conservative = ForecastEngine(StaticTimelineBuilder(value),
                                     ForecastSimulator(PHASE07_BASELINE_POLICY))
        self.assertEqual(conservative.assess(ledger((), balance="200", floor="100"),
                                             money("500")).amount_safe_to_pay, money("100"))

    def test_today_credit_does_not_erase_unsafe_opening(self):
        credit = flow("flow_today", date(2026, 4, 1), "300", Direction.CREDIT, "salary",
                      state=CashState.FUTURE_CONFIRMED)
        value = timeline((ForecastOccurrence(credit, ForecastOrigin.CANONICAL_FUTURE),))
        assessment = ForecastEngine(StaticTimelineBuilder(value)).assess(
            ledger((), balance="50", floor="100"), money("500"))
        self.assertEqual(assessment.amount_safe_to_pay, money("0"))
        self.assertIsNone(assessment.earliest_date_for_full_payment)

    def test_default_forecast_uses_one_consistent_release_policy(self):
        engine = ForecastEngine()
        detector = engine.timeline_builder.detector
        self.assertEqual(engine.simulator.policy, RELEASE_CANDIDATE_POLICY)
        self.assertEqual(detector.recent_window, RELEASE_CANDIDATE_POLICY.variable_essential_window)
        self.assertEqual(detector.variable_essential_estimator,
                         RELEASE_CANDIDATE_POLICY.variable_essential_estimator)

    def test_unresolved_evidence_fails_closed(self):
        unresolved = timeline(self.timeline.occurrences, unresolved=("event_missing",))
        result = self.simulator.simulate(unresolved, money("1000"), money("200"))
        self.assertFalse(result.safety_result.safe)
        self.assertEqual(result.safety_result.violations[-1].code, ViolationCode.UNRESOLVED_EVIDENCE)

    def test_flexible_stop_and_reduction_are_pure(self):
        rule = RecurrenceRule(
            "rule_flex", "user_A", RecurrenceCadence.MONTHLY, 1, AmountStrategy.FIXED,
            money("100"), "dining", Direction.DEBIT, ("event_flex",),
            DateRange(date(2026, 1, 1), date(2026, 6, 30)), date(2026, 3, 2), Decimal("1"),
            day_of_month=2, flexibility=Flexibility.REDUCIBLE_OR_STOPPABLE,
            minimum_allowed_amount=money("25"),
        )
        recurring_flow = flow("flow_flex", date(2026, 4, 2), "100", category="dining",
                              state=CashState.FUTURE_RESERVED, protected=False,
                              flexibility=Flexibility.REDUCIBLE_OR_STOPPABLE, event_id="event_flex")
        flex_timeline = timeline((ForecastOccurrence(recurring_flow, ForecastOrigin.RECURRENCE, rule.rule_id),),
                                 rules=(rule,))
        stopped = self.simulator.simulate(
            flex_timeline, money("1000"), money("200"),
            spending_changes=(SpendingChange(SpendingChangeAction.STOP, "event_flex"),),
        )
        reduced = self.simulator.simulate(
            flex_timeline, money("1000"), money("200"),
            spending_changes=(SpendingChange(SpendingChangeAction.REDUCE_TO, "event_flex", money("25")),),
        )
        self.assertEqual(stopped.days[1].closing_balance.amount, Decimal("1000"))
        self.assertEqual(reduced.days[1].closing_balance.amount, Decimal("975"))

    def test_monotonic_properties_and_zero_request(self):
        def capacity(start="1000", floor="200", debit="100", credit="300", request="800"):
            changed_timeline = timeline((
                ForecastOccurrence(flow("flow_due", date(2026, 4, 3), debit,
                                        state=CashState.FUTURE_RESERVED), ForecastOrigin.CANONICAL_FUTURE),
                ForecastOccurrence(flow("flow_pay", date(2026, 4, 5), credit, Direction.CREDIT,
                                        "salary", state=CashState.FUTURE_CONFIRMED), ForecastOrigin.CANONICAL_FUTURE),
            ))
            return ForecastEngine(StaticTimelineBuilder(changed_timeline)).assess(
                ledger((), balance=start, floor=floor), money(request)
            ).amount_safe_to_pay.amount
        base = capacity()
        self.assertGreaterEqual(capacity(start="1100"), base)
        self.assertLessEqual(capacity(floor="300"), base)
        self.assertLessEqual(capacity(debit="150"), base)
        self.assertGreaterEqual(capacity(credit="400"), base)
        zero = ForecastEngine(StaticTimelineBuilder(self.timeline)).assess(
            ledger((), balance="1000", floor="200"), money("0")
        )
        self.assertEqual(zero.amount_safe_to_pay.amount, Decimal(0))
        self.assertEqual(zero.earliest_date_for_full_payment, date(2026, 4, 1))
        json.dumps(redacted_forecast_trace(zero), sort_keys=True)


class StaticTimelineBuilder:
    def __init__(self, value):
        self.value = value

    def build(self, ledger_value, facts=()):
        return self.value


if __name__ == "__main__":
    unittest.main()
