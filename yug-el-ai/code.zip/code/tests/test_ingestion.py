from __future__ import annotations

from dataclasses import FrozenInstanceError
from datetime import date
from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from buywait.adapters.dataset import DatasetValidationError, load_dataset, resolve_dataset_dir
from buywait.domain.enums import Currency
from buywait.domain.errors import InvalidInputError, MissingExchangeRateError
from buywait.domain.fx import RateBook
from buywait.domain.models import ExchangeRate
from buywait.domain.money import Money
from tests.dataset_fixture import PNG, corpus, materialize

ROOT = Path(__file__).resolve().parents[2]


class IngestionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="buywait-input-test-")
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "dataset"
        self.tables = corpus()

    def load(self):
        materialize(self.path, self.tables)
        return load_dataset(self.path)

    def assert_issue(self, code: str, filename: str | None = None):
        with self.assertRaises(DatasetValidationError) as caught:
            self.load()
        issues = caught.exception.issues
        self.assertIn(code, {item.code for item in issues})
        if filename:
            self.assertTrue(any(item.code == code and item.source.filename == filename and item.source.line_number >= 2 for item in issues))
        return caught.exception

    def test_bundle_keeps_decimal_currency_and_complete_relevant_indexes(self) -> None:
        context = self.load()
        bundle = context.bundle("req_A")
        self.assertEqual(bundle.profile.current_available_balance.amount, Decimal("1000.10"))
        self.assertIsNone(bundle.events[0].amount)
        self.assertEqual(bundle.events[0].currency, Currency.EUR)
        self.assertEqual(len(bundle.payment_options), 2)
        self.assertEqual({item.message_id for item in bundle.messages}, {"msg_user", "msg_event", "msg_request"})
        self.assertEqual({item.image_id for item in bundle.images}, {"image_user", "image_event"})
        self.assertEqual(context.messages_by_event_id["event_A"][0].message_id, "msg_event")
        self.assertFalse(hasattr(bundle, "sample_expectations"))
        self.assertIn("sample_A", context.sample_expectations)
        self.assertEqual(context.source_locations[("financial_events.csv", "event_A")].line_number, 2)
        with self.assertRaises(TypeError):
            context.events_by_id["new"] = bundle.events[0]
        with self.assertRaises(FrozenInstanceError):
            context.events[0].currency = Currency.USD

    def test_malformed_decimals_are_rejected_without_echoing_values(self) -> None:
        for value in ("NaN", "Infinity", "1e3", "1,000", "$100", "1_000", "1.2.3", "secret-marker-987", "-1"):
            with self.subTest(value=value):
                self.tables["financial_events.csv"][1]["amount"] = value
                error = self.assert_issue("invalid_input", "financial_events.csv")
                self.assertNotIn(value, json.dumps(error.as_dict()))

    def test_unknown_currency(self) -> None:
        self.tables["financial_events.csv"][0]["currency"] = "XYZ"
        self.assert_issue("unsupported_currency", "financial_events.csv")

    def test_duplicates_and_cross_file_request_collision(self) -> None:
        self.tables["financial_events.csv"].append(dict(self.tables["financial_events.csv"][0]))
        self.assert_issue("duplicate_id", "financial_events.csv")
        self.tables = corpus()
        self.tables["sample_requests.csv"][0]["request_id"] = "req_A"
        self.assert_issue("duplicate_id", "sample_requests.csv")

    def test_unknown_profile_and_request_links(self) -> None:
        self.tables["requests.csv"][0]["user_id"] = "missing_user"
        self.assert_issue("missing_link", "requests.csv")
        self.tables = corpus()
        self.tables["request_payment_options.csv"][0]["request_id"] = "missing_request"
        self.assert_issue("missing_link", "request_payment_options.csv")

    def test_evidence_cannot_link_another_user_or_unknown_event(self) -> None:
        self.tables["messages.csv"][0]["related_event_id"] = "event_B"
        self.assert_issue("invalid_evidence_link", "messages.csv")
        self.tables = corpus()
        self.tables["images.csv"][0]["related_event_id"] = "absent_event"
        self.assert_issue("invalid_evidence_link", "images.csv")

    def test_lifecycle_self_cycle_and_cross_user_links(self) -> None:
        self.tables["financial_events.csv"][0]["linked_event_id"] = "event_A"
        self.assert_issue("lifecycle_cycle", "financial_events.csv")
        self.tables["financial_events.csv"][0]["linked_event_id"] = "event_B"
        self.assert_issue("invalid_lifecycle_link", "financial_events.csv")

    def test_missing_image_and_blank_amount_without_evidence(self) -> None:
        materialize(self.path, self.tables, omitted_images=("image_event",))
        with self.assertRaises(DatasetValidationError) as caught:
            load_dataset(self.path)
        self.assertIn("missing_image", {item.code for item in caught.exception.issues})
        self.tables["images.csv"][0]["related_event_id"] = ""
        self.assert_issue("missing_amount_evidence", "financial_events.csv")

    def test_invalid_image_identifier_cannot_traverse_directories(self) -> None:
        self.tables["images.csv"][0]["image_id"] = "../outside"
        self.assert_issue("invalid_input", "images.csv")

    def test_fx_missing_direction_and_date_report_exact_key(self) -> None:
        self.tables["exchange_rates.csv"][0].update(from_currency="USD", to_currency="EUR")
        error = self.assert_issue("missing_exchange_rate", "financial_events.csv")
        issue = next(item for item in error.issues if item.code == "missing_exchange_rate")
        self.assertEqual(issue.key, ("2026-09-11", "EUR", "USD"))
        self.tables = corpus()
        self.tables["exchange_rates.csv"][0]["rate_date"] = "2026-09-10"
        self.assert_issue("missing_exchange_rate", "financial_events.csv")
        self.tables["financial_events.csv"][0]["settlement_date"] = ""
        self.assert_issue("missing_fx_date", "financial_events.csv")

    def test_duplicate_fx_key(self) -> None:
        self.tables["exchange_rates.csv"].append(dict(self.tables["exchange_rates.csv"][0]))
        self.assert_issue("duplicate_rate_key", "exchange_rates.csv")

    def test_invalid_options_including_small_rounding_discrepancy(self) -> None:
        self.tables["request_payment_options.csv"][1]["total_payable_amount"] = "105"
        self.assert_issue("invalid_option_total", "request_payment_options.csv")
        self.tables = corpus()
        self.tables["request_payment_options.csv"][1]["payment_amount"] = "49"
        self.assert_issue("invalid_option_schedule", "request_payment_options.csv")
        self.tables = corpus()
        self.tables["request_payment_options.csv"][1].update(payment_amount="33.33", number_of_payments="3")
        self.assert_issue("invalid_option_schedule", "request_payment_options.csv")

    def test_missing_option_coverage(self) -> None:
        self.tables["request_payment_options.csv"] = [item for item in self.tables["request_payment_options.csv"] if item["request_id"] != "req_A"]
        self.assert_issue("missing_payment_options", "requests.csv")

    def test_output_template_coverage_and_header(self) -> None:
        self.tables["output.csv"].pop()
        self.assert_issue("missing_template_request")
        materialize(self.path, self.tables)
        (self.path / "output.csv").write_text("wrong,columns\n", encoding="utf-8")
        with self.assertRaises(DatasetValidationError) as caught:
            load_dataset(self.path)
        self.assertEqual(caught.exception.issues[0].code, "invalid_header")

    def test_booleans_dates_timestamps_and_integers(self) -> None:
        self.tables["requests.csv"][0]["allows_partial_payment"] = " YES "
        self.tables["messages.csv"][0]["sent_at"] = "2026-09-11T15:00:00+05:30"
        context = self.load()
        self.assertTrue(context.bundle("req_A").request.allows_partial_payment)
        self.assertEqual(context.messages_by_id["msg_user"].sent_at.isoformat(), "2026-09-11T09:30:00+00:00")
        for filename, field, value in (
            ("requests.csv", "allows_partial_payment", "perhaps"),
            ("requests.csv", "request_date", "20260912"),
            ("requests.csv", "request_date", "2026-02-30"),
            ("messages.csv", "sent_at", "2026-09-11T09:30:00"),
            ("request_payment_options.csv", "number_of_payments", "2.5"),
        ):
            with self.subTest(field=field):
                self.tables = corpus()
                self.tables[filename][0][field] = value
                self.assert_issue("invalid_input", filename)

    def test_media_is_lazy_scoped_and_bounded(self) -> None:
        materialize(self.path, self.tables)
        original_open = Path.open
        opened_images = []

        def tracked_open(path, *args, **kwargs):
            if path.suffix == ".png":
                opened_images.append(path.name)
            return original_open(path, *args, **kwargs)

        with patch.object(Path, "open", tracked_open):
            context = load_dataset(self.path)
            context.bundle("req_A")
            self.assertEqual(opened_images, [])
            self.assertEqual(context.read_image("req_A", "image_event"), PNG)
            self.assertEqual(opened_images, ["image_event.png"])
            with self.assertRaises(InvalidInputError):
                context.read_image("req_B", "image_event")
            with self.assertRaises(InvalidInputError):
                context.read_image("req_A", "image_other_request")
            with self.assertRaises(InvalidInputError):
                context.read_image("req_A", "image_event", max_bytes=8)

    def test_summary_is_private_and_ingestion_cannot_use_network(self) -> None:
        materialize(self.path, self.tables)
        with patch("socket.socket", side_effect=AssertionError("Network is forbidden")), patch("socket.getaddrinfo", side_effect=AssertionError("DNS is forbidden")):
            context = load_dataset(self.path)
        summary = json.dumps(context.summary())
        for forbidden in ("secret-marker-987", "Private", "1000.10", "req_A", "user_A", "event_A"):
            self.assertNotIn(forbidden, summary)

    def test_cli_explicit_path_and_nonzero_error_exit(self) -> None:
        materialize(self.path, self.tables)
        command = [sys.executable, str(ROOT / "code/main.py"), "--dataset-dir", str(self.path), "--profile-inputs"]
        result = subprocess.run(command, cwd=self.temp.name, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["counts"]["evaluation_requests"], 2)
        self.tables["financial_events.csv"][1]["amount"] = "broken"
        materialize(self.path, self.tables)
        result = subprocess.run(command, cwd=self.temp.name, capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertEqual(json.loads(result.stderr)["issues"][0]["field"], "amount")
        self.assertEqual(result.stdout, "")

    def test_explicit_relative_paths_use_repository_anchor(self) -> None:
        self.assertEqual(resolve_dataset_dir("dataset", repository_dir=Path(self.temp.name)), self.path)

    def test_csv_bom_multiline_record_and_structural_errors(self) -> None:
        self.tables["messages.csv"][0]["message_text"] = "Quoted, multiline\nprivate message"
        materialize(self.path, self.tables)
        message_path = self.path / "messages.csv"
        message_path.write_bytes(b"\xef\xbb\xbf" + message_path.read_bytes())
        context = load_dataset(self.path)
        self.assertEqual(context.messages_by_id["msg_user"].message_text, "Quoted, multiline\nprivate message")
        self.assertEqual(context.source_locations[("messages.csv", "msg_event")].line_number, 4)
        header = message_path.read_text(encoding="utf-8-sig").splitlines()[0]
        message_path.write_text(header + "\nonly,two\n", encoding="utf-8")
        with self.assertRaises(DatasetValidationError) as caught:
            load_dataset(self.path)
        self.assertEqual(caught.exception.issues[0].code, "invalid_row_width")
        message_path.write_text(header + '\n"unterminated\n', encoding="utf-8")
        with self.assertRaises(DatasetValidationError) as caught:
            load_dataset(self.path)
        self.assertEqual(caught.exception.issues[0].code, "invalid_csv")

    def test_missing_files_produce_source_located_error(self) -> None:
        with self.assertRaises(DatasetValidationError) as caught:
            load_dataset(self.path)
        self.assertEqual(len(caught.exception.issues), 9)
        self.assertEqual({item.code for item in caught.exception.issues}, {"file_unavailable"})

    def test_image_symlink_cannot_escape_dataset(self) -> None:
        materialize(self.path, self.tables, omitted_images=("image_event",))
        outside = Path(self.temp.name) / "outside.png"
        outside.write_bytes(PNG)
        try:
            (self.path / "media/images/image_event.png").symlink_to(outside)
        except OSError:
            self.skipTest("Host does not permit creating symbolic links")
        with self.assertRaises(DatasetValidationError) as caught:
            load_dataset(self.path)
        self.assertIn("invalid_image_path", {item.code for item in caught.exception.issues})


class FxTests(unittest.TestCase):
    def test_exact_conversion_is_independent_of_ambient_precision(self) -> None:
        book = RateBook([ExchangeRate(date(2026, 9, 11), Currency.EUR, Currency.USD, Decimal("1.2345"))])
        with localcontext() as arithmetic:
            arithmetic.prec = 3
            converted = book.convert(Money.parse("123456789.12345", "EUR"), Currency.USD, date(2026, 9, 11))
        self.assertEqual(converted.amount, Decimal("152407406.172899025"))
        self.assertEqual(book.convert(Money.parse("1.001", "USD"), Currency.USD, date(1900, 1, 1)).amount, Decimal("1.001"))
        with self.assertRaises(MissingExchangeRateError):
            book.convert(Money.parse("1", "USD"), Currency.EUR, date(2026, 9, 11))


@unittest.skipUnless((ROOT / "dataset").is_dir(), "Participant dataset is excluded from code.zip")
class SuppliedDatasetTests(unittest.TestCase):
    def test_every_request_resolves_with_complete_indexes_and_no_mutation(self) -> None:
        paths = sorted((ROOT / "dataset").rglob("*"))
        before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.is_file()}
        with patch("socket.socket", side_effect=AssertionError("Network is forbidden")):
            context = load_dataset()
        for request in context.evaluation_requests:
            bundle = context.bundle(request.request_id)
            self.assertEqual(bundle.profile.user_id, request.user_id)
            self.assertEqual(bundle.events, tuple(event for event in context.events if event.user_id == request.user_id))
            self.assertEqual(bundle.payment_options, tuple(option for option in context.payment_options if option.request_id == request.request_id))
            event_ids = {event.event_id for event in bundle.events}
            for items, actual in ((context.messages, bundle.messages), (context.images, bundle.images)):
                expected = tuple(item for item in items if item.user_id == request.user_id and (
                    item.request_id in {None, request.request_id} or item.related_event_id in event_ids))
                self.assertEqual(actual, expected)
        after = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in before}
        self.assertEqual(before, after)

    def test_default_cli_path_works_from_unrelated_directory(self) -> None:
        with tempfile.TemporaryDirectory(prefix="buywait-cwd-test-") as directory:
            result = subprocess.run([sys.executable, str(ROOT / "code/main.py"), "--validate-inputs"],
                                    cwd=directory, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)["valid"])


if __name__ == "__main__":
    unittest.main()
