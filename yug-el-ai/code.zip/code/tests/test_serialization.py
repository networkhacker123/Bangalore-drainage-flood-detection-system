from datetime import date
import json
import unittest

from buywait.domain import (
    AffordabilityStatus,
    Decision,
    Money,
    Payment,
    PaymentMethod,
    SpendingChange,
    SpendingChangeAction,
)
from buywait.domain.serialization import (
    OUTPUT_COLUMNS,
    decision_from_json,
    decision_to_csv_row,
    decision_to_dict,
    decision_to_json,
)


def sample_decision() -> Decision:
    return Decision(
        request_id="request_contract",
        request_date=date(2026, 9, 12),
        requested_amount=Money.parse("1000.125", "USD"),
        amount_safe_to_pay=Money.parse("300.125", "USD"),
        affordability_status=AffordabilityStatus.AFFORDABLE_WITH_PLAN,
        recommended_payment_method=PaymentMethod.PARTIAL_PAYMENT,
        payment_plan=(
            Payment(date(2026, 9, 12), Money.parse("300.125", "USD"), 1),
            Payment(date(2026, 9, 30), Money.parse("700", "USD"), 2),
        ),
        earliest_date_for_full_payment=date(2026, 9, 30),
        spending_changes_needed=(
            SpendingChange(SpendingChangeAction.REDUCE_TO, "event_9", Money.parse("50", "USD")),
        ),
        decision_explanation="Pay part now and the remainder after confirmed income.",
        selected_candidate_id="candidate_1",
        audit_trace_id="trace_1",
    )


def contains_float(value: object) -> bool:
    if isinstance(value, float):
        return True
    if isinstance(value, dict):
        return any(contains_float(item) for item in value.values())
    if isinstance(value, list):
        return any(contains_float(item) for item in value)
    return False


class SerializationTests(unittest.TestCase):
    def test_decision_json_round_trip_preserves_decimal_exactly(self) -> None:
        original = sample_decision()
        encoded = decision_to_json(original)
        decoded = decision_from_json(encoded)
        self.assertEqual(decoded, original)
        self.assertIn('\"amount\":\"1000.125\"', encoded)

    def test_json_tree_contains_no_binary_float(self) -> None:
        data = json.loads(decision_to_json(sample_decision()))
        self.assertFalse(contains_float(data))
        self.assertFalse(contains_float(decision_to_dict(sample_decision())))

    def test_csv_column_order_and_exact_formats(self) -> None:
        row = decision_to_csv_row(sample_decision())
        self.assertEqual(tuple(row), OUTPUT_COLUMNS)
        self.assertEqual(row["amount_safe_to_pay"], "300.12")
        self.assertEqual(row["payment_plan"], "2026-09-12:300.13|2026-09-30:700")
        self.assertEqual(row["spending_changes_needed"], "reduce_to:event_9:50")


if __name__ == "__main__":
    unittest.main()
