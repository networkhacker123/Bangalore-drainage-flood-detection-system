"""Dependency-free contract tests."""
