from datetime import date, datetime, timezone
from decimal import Decimal
import unittest

from buywait.domain import (
    CashState, Currency, Direction, EventStatus, EventType, EvidenceFact,
    EvidenceFactType, EvidenceProvenance, EvidenceSourceKind, ExchangeRate,
    EvaluationBundle, FinancialRequest, Flexibility, LifecycleDisposition,
    Money, PaymentMethod, Profile, RawEvent, RequestType,
)
from buywait.evidence.types import EvidenceConflict, EvidenceIssue, EvidenceResult
from buywait.ledger import CanonicalLedgerBuilder


AS_OF = date(2026, 9, 12)


def profile() -> Profile:
    return Profile(
        "user_A", Currency.USD, Money.parse("1000", "USD"), Money.parse("100", "USD"),
        protected_categories=frozenset({"rent", "salary"}),
        payment_methods_user_will_consider=frozenset({PaymentMethod.FULL_PAYMENT}),
    )


def request() -> FinancialRequest:
    return FinancialRequest(
        "request_A", "user_A", AS_OF, RequestType.PURCHASE, Money.parse("100", "USD"),
        date(2026, 10, 12), False, "Synthetic request",
    )


def event(event_id: str, *, event_type=EventType.EXPENSE, description="Synthetic event",
          category="shopping", direction=Direction.DEBIT, amount="10", currency=Currency.USD,
          event_date=date(2026, 9, 10), settlement_date=date(2026, 9, 15),
          status=EventStatus.PENDING, linked_event_id=None, flexibility=Flexibility.FIXED):
    return RawEvent(
        event_id, "user_A", event_type, description, category, direction,
        Money.parse(amount, currency) if amount is not None else None,
        event_date, settlement_date, status, linked_event_id, flexibility,
        currency=currency,
    )


def fact(fact_id: str, kind: EvidenceFactType, value, *, subject="event", scope="one_time",
         related_event_id=None, effective_date=None, explicit=False, source="message_A",
         source_identity="trusted-source", currency=Currency.USD):
    return EvidenceFact(
        fact_id, kind, value,
        EvidenceProvenance(EvidenceSourceKind.MESSAGE, source,
                           datetime(2026, 9, 11, tzinfo=timezone.utc),
                           provider="fixture", source_identity=source_identity),
        related_event_id, effective_date, currency, Decimal("0.95"),
        subject=subject, scope=scope, explicit=explicit,
    )


def bundle(events, rates=()):
    return EvaluationBundle(request(), profile(), tuple(events), (), (), (), tuple(rates))


def evidence(facts=(), *, issues=(), conflicts=()):
    return EvidenceResult("request_A", tuple(facts), tuple(issues), tuple(conflicts), (), (), ())


class CanonicalLedgerTests(unittest.TestCase):
    def setUp(self):
        self.builder = CanonicalLedgerBuilder()

    def test_pending_refund_is_ignored(self):
        refund = event("refund", event_type=EventType.REFUND, direction=Direction.CREDIT,
                       status=EventStatus.PENDING)
        ledger = self.builder.build(bundle((refund,)), evidence())
        self.assertEqual(ledger.event_dispositions[0].disposition,
                         LifecycleDisposition.PENDING_CREDIT_IGNORED)
        self.assertEqual(ledger.forecast_flows, ())

    def test_failed_debit_with_newer_outstanding_evidence_is_reserved(self):
        failed = event("failed", status=EventStatus.FAILED,
                       settlement_date=date(2026, 9, 10))
        outstanding = fact("outstanding", EvidenceFactType.CASH_STATE, "outstanding_debit",
                           related_event_id="failed", explicit=True)
        ledger = self.builder.build(bundle((failed,)), evidence((outstanding,)))
        disposition = ledger.event_dispositions[0]
        self.assertEqual(disposition.disposition, LifecycleDisposition.FUTURE_DEBIT)
        self.assertEqual(ledger.forecast_flows[0].effective_date, AS_OF)
        self.assertEqual(ledger.forecast_flows[0].cash_state, CashState.FUTURE_RESERVED)

    def test_failed_parent_and_scheduled_retry_do_not_double_reserve(self):
        failed = event("failed", status=EventStatus.FAILED)
        retry = event("retry", status=EventStatus.SCHEDULED, linked_event_id="failed")
        outstanding = fact("outstanding", EvidenceFactType.CASH_STATE, "outstanding_debit",
                           related_event_id="failed", explicit=True)
        ledger = self.builder.build(bundle((failed, retry)), evidence((outstanding,)))
        self.assertEqual(len(ledger.forecast_flows), 1)
        self.assertEqual(ledger.forecast_flows[0].source_event_ids, ("retry",))

    def test_debit_and_settled_reversal_remain_history_only(self):
        debit = event("charge", description="Card charge later reversed", status=EventStatus.SETTLED,
                      settlement_date=date(2026, 9, 1))
        reversal = event("reversal", event_type=EventType.REFUND,
                         description="Settled card charge reversal", direction=Direction.CREDIT,
                         status=EventStatus.SETTLED, settlement_date=date(2026, 9, 2),
                         linked_event_id="charge")
        ledger = self.builder.build(bundle((debit, reversal)), evidence())
        self.assertEqual(len(ledger.historical_flows), 2)
        self.assertEqual(ledger.forecast_flows, ())
        self.assertEqual(ledger.current_available_balance, profile().current_available_balance)
        self.assertEqual(ledger.historical_series_candidates, ())

    def test_estimate_replaced_by_linked_settlement_is_not_counted_twice(self):
        estimate = event("estimate", status=EventStatus.PENDING, amount="125",
                         description="Merchant estimate")
        settlement = event("settlement", status=EventStatus.SETTLED, amount="125",
                           description="Final merchant settlement",
                           settlement_date=date(2026, 9, 11), linked_event_id="estimate")
        ledger = self.builder.build(bundle((estimate, settlement)), evidence())
        dispositions = {item.event_id: item.disposition for item in ledger.event_dispositions}
        self.assertEqual(dispositions["estimate"], LifecycleDisposition.DUPLICATE)
        self.assertEqual(dispositions["settlement"], LifecycleDisposition.HISTORICAL_BALANCE)
        self.assertEqual(len(ledger.flows), 1)

    def test_settled_investment_sale_is_history_and_valuation_is_non_cash(self):
        purchase = event("purchase", event_type=EventType.INVESTMENT_PURCHASE,
                         category="investment", status=EventStatus.SETTLED,
                         settlement_date=date(2026, 8, 1))
        valuation = event("valuation", event_type=EventType.INVESTMENT_VALUATION,
                          category="investment", direction=Direction.NON_CASH,
                          status=EventStatus.UNREALIZED, settlement_date=None,
                          linked_event_id="purchase")
        sale = event("sale", event_type=EventType.INVESTMENT_SALE,
                     category="investment", direction=Direction.CREDIT,
                     status=EventStatus.SETTLED, settlement_date=date(2026, 9, 1),
                     linked_event_id="purchase")
        ledger = self.builder.build(bundle((purchase, valuation, sale)), evidence())
        dispositions = {item.event_id: item.disposition for item in ledger.event_dispositions}
        self.assertEqual(dispositions["valuation"], LifecycleDisposition.NON_CASH)
        self.assertEqual(dispositions["sale"], LifecycleDisposition.HISTORICAL_BALANCE)
        self.assertFalse(any(flow.source_event_ids == ("valuation",) for flow in ledger.flows))

    def test_explicit_internal_transfer_removes_exact_pair(self):
        debit = event("transfer_out", status=EventStatus.SETTLED,
                      settlement_date=date(2026, 9, 10), amount="250")
        credit = event("transfer_in", event_type=EventType.INCOME, category="transfer",
                       direction=Direction.CREDIT, status=EventStatus.SETTLED,
                       settlement_date=date(2026, 9, 10), amount="250")
        internal = fact("internal", EvidenceFactType.INTERNAL_TRANSFER, "internal",
                        subject="transfer", explicit=True)
        ledger = self.builder.build(bundle((debit, credit)), evidence((internal,)))
        self.assertEqual(ledger.flows, ())
        self.assertEqual({item.disposition for item in ledger.event_dispositions},
                         {LifecycleDisposition.INTERNAL_TRANSFER})

    def test_dated_salary_amendment_and_arrears_stay_separate(self):
        salary = event("salary_history", event_type=EventType.INCOME, category="salary",
                       direction=Direction.CREDIT, status=EventStatus.SETTLED,
                       settlement_date=date(2026, 8, 15), amount="1000")
        facts = (
            fact("confirmed", EvidenceFactType.STATUS, "confirmed", subject="salary",
                 scope="recurring", effective_date=date(2026, 9, 15)),
            fact("salary_amount", EvidenceFactType.AMOUNT, Decimal("1100"), subject="salary",
                 scope="recurring", effective_date=date(2026, 9, 15), explicit=True),
            fact("salary_date", EvidenceFactType.SETTLEMENT_DATE, date(2026, 9, 15),
                 subject="salary", scope="recurring", effective_date=date(2026, 9, 15), explicit=True),
            fact("arrears", EvidenceFactType.AMOUNT, Decimal("200"), subject="arrears",
                 effective_date=date(2026, 9, 15)),
        )
        ledger = self.builder.build(bundle((salary,)), evidence(facts))
        future = [(flow.amount.amount, flow.evidence_fact_ids) for flow in ledger.forecast_flows]
        self.assertEqual({amount for amount, _ in future}, {Decimal("1100"), Decimal("200")})
        self.assertEqual(len(future), 2)

    def test_foreign_debit_and_confirmed_salary_use_exact_dated_rates(self):
        debit = event("foreign_debit", currency=Currency.EUR, amount="10",
                      settlement_date=date(2026, 9, 15))
        salary = event("foreign_salary", event_type=EventType.INCOME, category="salary",
                       direction=Direction.CREDIT, currency=Currency.EUR, amount="50",
                       status=EventStatus.SCHEDULED, settlement_date=date(2026, 9, 20))
        rates = (
            ExchangeRate(date(2026, 9, 15), Currency.EUR, Currency.USD, Decimal("1.20")),
            ExchangeRate(date(2026, 9, 20), Currency.EUR, Currency.USD, Decimal("1.25")),
        )
        ledger = self.builder.build(bundle((debit, salary), rates), evidence())
        by_event = {flow.source_event_ids[0]: flow for flow in ledger.forecast_flows}
        self.assertEqual(by_event["foreign_debit"].amount.amount, Decimal("12.00"))
        self.assertEqual(by_event["foreign_salary"].amount.amount, Decimal("62.50"))
        self.assertEqual(by_event["foreign_debit"].original_amount.currency, Currency.EUR)
        self.assertEqual(by_event["foreign_debit"].fx_rate_date, date(2026, 9, 15))

    def test_evidence_only_foreign_salary_uses_its_supported_future_rate(self):
        salary = event("salary_history", event_type=EventType.INCOME, category="salary",
                       direction=Direction.CREDIT, amount="40", currency=Currency.EUR,
                       status=EventStatus.SETTLED, settlement_date=date(2026, 8, 20))
        facts = (
            fact("confirmed", EvidenceFactType.STATUS, "confirmed", subject="salary",
                 scope="recurring", effective_date=date(2026, 9, 20)),
            fact("salary_date", EvidenceFactType.SETTLEMENT_DATE, date(2026, 9, 20),
                 subject="salary", scope="recurring", effective_date=date(2026, 9, 20),
                 explicit=True),
            fact("salary_amount", EvidenceFactType.AMOUNT, Decimal("50"), subject="salary",
                 scope="recurring", effective_date=date(2026, 9, 20), explicit=True,
                 currency=Currency.EUR),
        )
        rates = (ExchangeRate(date(2026, 9, 20), Currency.EUR, Currency.USD, Decimal("1.25")),)
        ledger = self.builder.build(bundle((salary,), rates), evidence(facts))
        future = ledger.forecast_flows[0]
        self.assertEqual(future.amount, Money.parse("62.50", "USD"))
        self.assertEqual(future.original_amount, Money.parse("50", "EUR"))
        self.assertEqual(future.fx_rate, Decimal("1.25"))

    def test_same_day_amount_conflict_uses_financially_safer_debit(self):
        debit = event("amended", amount="100", settlement_date=date(2026, 9, 15))
        facts = (
            fact("amount_low", EvidenceFactType.AMOUNT, Decimal("90"),
                 related_event_id="amended", effective_date=date(2026, 9, 15), explicit=True,
                 source="message_low", source_identity="merchant"),
            fact("amount_high", EvidenceFactType.AMOUNT, Decimal("110"),
                 related_event_id="amended", effective_date=date(2026, 9, 15), explicit=True,
                 source="message_high", source_identity="merchant"),
        )
        conflict = EvidenceConflict(("amount_low", "amount_high"), None, "same_day_disagreement")
        ledger = self.builder.build(bundle((debit,)), evidence(facts, conflicts=(conflict,)))
        self.assertEqual(ledger.forecast_flows[0].amount, Money.parse("110", "USD"))
        self.assertIn("unresolved_evidence_conflict", {item.code for item in ledger.warnings})

    def test_unrelated_salary_clause_does_not_fill_linked_expense_amount(self):
        expense = event("receipt", amount=None, status=EventStatus.SETTLED,
                        settlement_date=date(2026, 9, 11))
        salary = fact("salary", EvidenceFactType.AMOUNT, Decimal("1296"), subject="salary",
                      scope="recurring", related_event_id="receipt", currency=Currency.USD)
        ledger = self.builder.build(bundle((expense,)), evidence((salary,)))
        self.assertEqual(ledger.event_dispositions[0].disposition, LifecycleDisposition.UNRESOLVED)
        self.assertEqual(ledger.event_dispositions[0].rule_code, "mandatory_amount_unresolved")
        self.assertEqual(ledger.evidence_dispositions[0].action, "deferred_to_recurrence")

    def test_missing_parent_and_unresolved_conflict_are_diagnostics(self):
        orphan = event("orphan", linked_event_id="missing")
        conflict = EvidenceConflict(("fact_a", "fact_b"), None, "unresolved_disagreement")
        ledger = self.builder.build(bundle((orphan,)), evidence(conflicts=(conflict,)))
        self.assertEqual(ledger.event_dispositions[0].disposition, LifecycleDisposition.UNRESOLVED)
        codes = {warning.code for warning in ledger.warnings}
        self.assertIn("missing_lifecycle_parent", codes)
        self.assertIn("unresolved_evidence_conflict", codes)

    def test_cycle_is_quarantined_and_fingerprint_is_deterministic(self):
        first = event("first", linked_event_id="second")
        second = event("second", linked_event_id="first")
        one = self.builder.build(bundle((first, second)), evidence())
        two = self.builder.build(bundle((first, second)), evidence())
        self.assertEqual(one.fingerprint, two.fingerprint)
        self.assertEqual({item.disposition for item in one.event_dispositions},
                         {LifecycleDisposition.UNRESOLVED})
        self.assertIn("lifecycle_cycle", {warning.code for warning in one.warnings})


if __name__ == "__main__":
    unittest.main()
