from decimal import Decimal
import unittest

from buywait.domain import Currency, InvalidInputError, Money
from buywait.domain.money import exact_decimal_text, format_plan_amount, format_safe_amount


class MoneyTests(unittest.TestCase):
    def test_rejects_binary_float(self) -> None:
        with self.assertRaises(InvalidInputError):
            Money(0.1, Currency.USD)  # type: ignore[arg-type]

    def test_exact_decimal_text_never_uses_scientific_notation(self) -> None:
        self.assertEqual(exact_decimal_text(Decimal("1E+7")), "10000000")
        self.assertEqual(exact_decimal_text(Decimal("0.0100")), "0.0100")

    def test_safe_capacity_never_rounds_up(self) -> None:
        self.assertEqual(format_safe_amount(Decimal("12.349")), "12.34")

    def test_plan_format_is_deterministic(self) -> None:
        self.assertEqual(format_plan_amount(Decimal("300.000")), "300")
        self.assertEqual(format_plan_amount(Decimal("12.345")), "12.35")

    def test_currency_mismatch_is_rejected(self) -> None:
        with self.assertRaises(InvalidInputError):
            _ = Money.parse("1", "USD") + Money.parse("1", "EUR")


if __name__ == "__main__":
    unittest.main()
