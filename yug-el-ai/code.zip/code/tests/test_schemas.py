import json
from pathlib import Path
import unittest

from buywait.contracts.schema_registry import SCHEMA_FILES, SCHEMA_VERSIONS


ROOT = Path(__file__).resolve().parents[2]


class SchemaTests(unittest.TestCase):
    def test_all_registered_schemas_are_valid_json_with_version_const(self) -> None:
        self.assertEqual(set(SCHEMA_FILES), set(SCHEMA_VERSIONS))
        for name, relative_path in SCHEMA_FILES.items():
            schema = json.loads((ROOT / relative_path).read_text(encoding="utf-8"))
            self.assertEqual(schema["$schema"], "https://json-schema.org/draft/2020-12/schema")
            self.assertTrue(schema["$id"].endswith(".json"))
            self.assertEqual(
                schema["properties"]["schema_version"]["const"],
                SCHEMA_VERSIONS[name],
            )

    def test_project_state_uses_registered_version(self) -> None:
        state = json.loads((ROOT / "docs/project_state.json").read_text(encoding="utf-8"))
        self.assertEqual(state["schema_version"], SCHEMA_VERSIONS["project_state"])


if __name__ == "__main__":
    unittest.main()
