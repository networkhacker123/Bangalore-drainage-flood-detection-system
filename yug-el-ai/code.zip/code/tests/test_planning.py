from datetime import date
from decimal import Decimal
import unittest

from buywait.adapters.dataset import load_dataset
from buywait.application import BuyWaitDecisionService
from buywait.domain.enums import Currency, PaymentMethod, SpendingChangeAction
from buywait.domain.errors import InvalidInputError
from buywait.domain.models import CandidatePlan, Payment, SpendingChange
from buywait.domain.money import Money
from buywait.domain.serialization import decision_to_csv_row
from buywait.evidence.service import EvidenceService
from buywait.planning.output import decision_from_csv_row
from buywait.planning.ranking import rank_key


def candidate(identifier, *, total="100", first=date(2026, 1, 1), count=1,
              changes=(), option=None, completion=None):
    amount = Money(Decimal(total) / count, Currency.USD)
    payments = tuple(Payment(first, amount, index + 1) for index in range(count))
    return CandidatePlan(
        identifier, "request_test", PaymentMethod.FULL_PAYMENT, payments, changes,
        Money(total, Currency.USD), option, True, completion or first,
    )


class RankingTests(unittest.TestCase):
    def test_official_lexicographic_order_and_transitivity(self):
        deadline = date(2026, 1, 31)
        low_cost = candidate("low", total="99")
        high_cost = candidate("high", total="100")
        later = candidate("later", total="100", first=date(2026, 1, 2))
        self.assertLess(rank_key(low_cost, deadline), rank_key(high_cost, deadline))
        self.assertLess(rank_key(high_cost, deadline), rank_key(later, deadline))
        self.assertLess(rank_key(low_cost, deadline), rank_key(later, deadline))

    def test_numeric_option_id_is_final_tiebreaker(self):
        deadline = date(2026, 1, 31)
        first = candidate("a", option="payment_option_9")
        second = candidate("b", option="payment_option_10")
        self.assertLess(rank_key(first, deadline), rank_key(second, deadline))

    def test_four_spending_changes_are_rejected_at_domain_boundary(self):
        changes = tuple(SpendingChange(SpendingChangeAction.STOP, f"event_{index}")
                        for index in range(4))
        with self.assertRaises(InvalidInputError):
            candidate("too_many", changes=changes)


class EndToEndDecisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.context = load_dataset()
        cls.service = BuyWaitDecisionService(
            cls.context, evidence_service=EvidenceService(cls.context, ocr=None, model=None, cache=None)
        )

    def test_full_payment_is_selected_over_same_day_wait(self):
        result = self.service.decide("request_01")
        self.assertEqual(result.decision.recommended_payment_method, PaymentMethod.FULL_PAYMENT)
        waits = [item for item in result.search.candidates if item.payment_method is PaymentMethod.WAIT]
        self.assertTrue(waits)
        self.assertTrue(all(not item.eligible for item in waits))

    def test_csv_row_roundtrip_is_canonical(self):
        decision = self.service.decide("request_01").decision
        row = decision_to_csv_row(decision)
        restored = decision_from_csv_row(row, self.context.requests_by_id[decision.request_id])
        self.assertEqual(decision_to_csv_row(restored), row)

    def test_expected_public_wait_and_installment_shapes_are_legal(self):
        for request_id in ("request_02", "request_03"):
            result = self.service.decide(request_id)
            self.assertTrue(result.search.winner is None or result.search.winner.safety_result.safe)
            self.assertTrue(all(
                payment.payment_date <= self.context.requests_by_id[request_id].desired_completion_date
                for payment in result.decision.payment_plan
            ))

    def test_fee_bearing_installment_preserves_supplied_option(self):
        result = self.service.decide("request_02")
        self.assertEqual(result.decision.recommended_payment_method, PaymentMethod.INSTALLMENTS)
        winner = result.search.winner
        option = self.context.options_by_id[winner.payment_option_id]
        self.assertEqual(sum((item.amount.amount for item in winner.payments), Decimal(0)),
                         option.total_payable_amount.amount)
        self.assertGreaterEqual(option.total_payable_amount.amount,
                                self.context.requests_by_id["request_02"].requested_amount.amount)

    def test_partial_wait_and_change_dependent_plans_obey_shapes(self):
        partial = self.service.decide("request_46").decision
        self.assertEqual(partial.recommended_payment_method, PaymentMethod.PARTIAL_PAYMENT)
        self.assertEqual(len(partial.payment_plan), 2)
        self.assertEqual(partial.payment_plan[0].amount, partial.amount_safe_to_pay)

        wait = self.service.decide("request_52").decision
        self.assertEqual(wait.recommended_payment_method, PaymentMethod.WAIT)
        self.assertGreater(wait.payment_plan[0].payment_date, wait.request_date)

        changed = self.service.decide("request_49").decision
        self.assertTrue(changed.spending_changes_needed)
        self.assertLessEqual(len(changed.spending_changes_needed), 3)

    def test_unresolved_mandatory_evidence_is_complete_fail_closed_decision(self):
        result = self.service.decide("request_101")
        self.assertIsNone(result.search.winner)
        self.assertEqual(result.decision.recommended_payment_method, PaymentMethod.NOT_RECOMMENDED)
        self.assertEqual(result.decision.amount_safe_to_pay.amount, Decimal(0))
        self.assertEqual(result.decision.payment_plan, ())


if __name__ == "__main__":
    unittest.main()
