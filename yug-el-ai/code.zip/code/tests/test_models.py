from dataclasses import FrozenInstanceError
from datetime import date
import unittest

from buywait.domain import (
    AffordabilityStatus,
    Currency,
    Decision,
    EvaluationBundle,
    FinancialRequest,
    InvalidInputError,
    Money,
    PaymentMethod,
    Profile,
    RequestType,
)


def profile(user_id: str = "user_1") -> Profile:
    return Profile(
        user_id=user_id,
        home_currency=Currency.USD,
        current_available_balance=Money.parse("2000", "USD"),
        minimum_balance_to_keep=Money.parse("500", "USD"),
        payment_methods_user_will_consider=frozenset({PaymentMethod.FULL_PAYMENT}),
    )


def request(user_id: str = "user_1") -> FinancialRequest:
    return FinancialRequest(
        request_id="request_1",
        user_id=user_id,
        request_date=date(2026, 9, 12),
        request_type=RequestType.PURCHASE,
        requested_amount=Money.parse("1000", "USD"),
        desired_completion_date=date(2026, 10, 1),
        allows_partial_payment=False,
        request_text="Can I afford it?",
    )


class ModelTests(unittest.TestCase):
    def test_models_are_immutable(self) -> None:
        value = profile()
        with self.assertRaises(FrozenInstanceError):
            value.user_id = "changed"  # type: ignore[misc]

    def test_bundle_rejects_cross_user_join(self) -> None:
        with self.assertRaises(InvalidInputError):
            EvaluationBundle(request(), profile("user_2"), (), (), (), (), ())

    def test_affordable_now_relationship_is_enforced(self) -> None:
        with self.assertRaises(InvalidInputError):
            Decision(
                request_id="request_1",
                request_date=date(2026, 9, 12),
                requested_amount=Money.parse("1000", "USD"),
                amount_safe_to_pay=Money.parse("1000", "USD"),
                affordability_status=AffordabilityStatus.AFFORDABLE_NOW,
                recommended_payment_method=PaymentMethod.INSTALLMENTS,
                payment_plan=(),
                earliest_date_for_full_payment=date(2026, 9, 12),
                spending_changes_needed=(),
                decision_explanation="Invalid on purpose.",
            )

    def test_safe_amount_cannot_exceed_request(self) -> None:
        with self.assertRaises(InvalidInputError):
            Decision(
                request_id="request_1",
                request_date=date(2026, 9, 12),
                requested_amount=Money.parse("1000", "USD"),
                amount_safe_to_pay=Money.parse("1000.01", "USD"),
                affordability_status=AffordabilityStatus.NOT_AFFORDABLE,
                recommended_payment_method=PaymentMethod.NOT_RECOMMENDED,
                payment_plan=(),
                earliest_date_for_full_payment=None,
                spending_changes_needed=(),
                decision_explanation="Invalid on purpose.",
            )


if __name__ == "__main__":
    unittest.main()
