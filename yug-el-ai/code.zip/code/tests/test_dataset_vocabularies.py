import csv
from pathlib import Path
import unittest

from buywait.domain.enums import (
    Currency,
    Direction,
    EventStatus,
    EventType,
    Flexibility,
    MessageSource,
    PaymentMethod,
    RequestType,
)


ROOT = Path(__file__).resolve().parents[2]
DATASET = ROOT / "dataset"


def values(filename: str, column: str) -> set[str]:
    with (DATASET / filename).open(encoding="utf-8-sig", newline="") as handle:
        return {row[column] for row in csv.DictReader(handle) if row[column]}


class DatasetVocabularyTests(unittest.TestCase):
    @unittest.skipUnless(DATASET.exists(), "participant dataset is intentionally excluded from code.zip")
    def test_closed_domain_vocabularies_cover_every_dataset_value(self) -> None:
        checks = (
            (values("requests.csv", "request_type"), RequestType),
            (values("financial_profiles.csv", "home_currency"), Currency),
            (values("financial_events.csv", "currency"), Currency),
            (values("financial_events.csv", "event_type"), EventType),
            (values("financial_events.csv", "direction"), Direction),
            (values("financial_events.csv", "status"), EventStatus),
            (values("financial_events.csv", "flexibility"), Flexibility),
            (values("messages.csv", "source_type"), MessageSource),
            (values("request_payment_options.csv", "payment_method"), PaymentMethod),
        )
        for observed, enum_type in checks:
            with self.subTest(enum=enum_type.__name__):
                self.assertTrue(observed <= {item.value for item in enum_type})

        considered: set[str] = set()
        with (DATASET / "financial_profiles.csv").open(
            encoding="utf-8-sig", newline=""
        ) as handle:
            for row in csv.DictReader(handle):
                considered.update(filter(None, row["payment_methods_user_will_consider"].split("|")))
        self.assertTrue(considered <= {item.value for item in PaymentMethod})


if __name__ == "__main__":
    unittest.main()
