import subprocess
import sys
from pathlib import Path
import unittest

from buywait import __version__


ROOT = Path(__file__).resolve().parents[2]


class CliContractTests(unittest.TestCase):
    def test_required_entry_point_reports_version(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(ROOT / "code" / "main.py"), "--version"],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertEqual(completed.stdout.strip(), __version__)


if __name__ == "__main__":
    unittest.main()
