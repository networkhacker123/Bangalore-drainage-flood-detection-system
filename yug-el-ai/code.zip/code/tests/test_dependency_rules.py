import ast
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[2]
DOMAIN = ROOT / "code" / "buywait" / "domain"
FORBIDDEN_ROOTS = {
    "fastapi", "flask", "pydantic", "sqlalchemy", "openai", "anthropic",
    "requests", "httpx", "pandas", "numpy",
}
FORBIDDEN_INTERNAL_PREFIXES = (
    "buywait.application", "buywait.adapters", "buywait.contracts",
    "buywait.api", "buywait.providers",
)


class DependencyRuleTests(unittest.TestCase):
    def test_domain_has_no_outward_or_framework_imports(self) -> None:
        violations: list[str] = []
        for path in DOMAIN.rglob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                names: list[str] = []
                if isinstance(node, ast.Import):
                    names = [item.name for item in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                    names = [node.module]
                for name in names:
                    forbidden = (
                        name.split(".", 1)[0] in FORBIDDEN_ROOTS
                        or name.startswith(FORBIDDEN_INTERNAL_PREFIXES)
                    )
                    if forbidden:
                        violations.append(f"{path.relative_to(ROOT)}:{node.lineno}:{name}")
        self.assertEqual(violations, [])


if __name__ == "__main__":
    unittest.main()
